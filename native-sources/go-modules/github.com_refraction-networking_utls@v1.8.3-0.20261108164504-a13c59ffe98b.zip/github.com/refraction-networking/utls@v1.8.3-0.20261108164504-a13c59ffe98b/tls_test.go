// Copyright 2012 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package tls

import (
	"bytes"
	"context"
	"crypto"
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/fips140"
	"crypto/mldsa"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/asn1"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math"
	"math/big"
	"net"
	"os"
	"reflect"
	"slices"
	"strings"
	"testing"
	"time"

	"golang.org/x/crypto/cryptobyte"

	"github.com/refraction-networking/utls/internal/boring"
	"github.com/refraction-networking/utls/internal/cryptotest"
	"github.com/refraction-networking/utls/internal/fips140tls"
	"github.com/refraction-networking/utls/internal/testenv"
)

var testTime = func() time.Time { return time.Unix(1476984729, 0) }

var testConfigServer = &Config{
	Time: testTime,
	Certificates: []Certificate{testECDSAP256Cert, testRSA2048Cert, testEd25519Cert, testSNICert,
		testMLDSA44Cert, testMLDSA65Cert, testMLDSA87Cert},
	ClientCAs: testClientRootCertPool,
}

var testConfigClient = &Config{
	Time: testTime,
	Certificates: []Certificate{testClientECDSAP256Cert, testClientRSA2048Cert, testClientEd25519Cert,
		testClientMLDSA44Cert, testClientMLDSA65Cert, testClientMLDSA87Cert},
	RootCAs:    testRootCertPool,
	ServerName: "test.golang.example",
}

func TestX509KeyPair(t *testing.T) {
	var rsaCertPEM = `-----BEGIN CERTIFICATE-----
MIIB0zCCAX2gAwIBAgIJAI/M7BYjwB+uMA0GCSqGSIb3DQEBBQUAMEUxCzAJBgNV
BAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBX
aWRnaXRzIFB0eSBMdGQwHhcNMTIwOTEyMjE1MjAyWhcNMTUwOTEyMjE1MjAyWjBF
MQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEhMB8GA1UECgwYSW50
ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANLJ
hPHhITqQbPklG3ibCVxwGMRfp/v4XqhfdQHdcVfHap6NQ5Wok/4xIA+ui35/MmNa
rtNuC+BdZ1tMuVCPFZcCAwEAAaNQME4wHQYDVR0OBBYEFJvKs8RfJaXTH08W+SGv
zQyKn0H8MB8GA1UdIwQYMBaAFJvKs8RfJaXTH08W+SGvzQyKn0H8MAwGA1UdEwQF
MAMBAf8wDQYJKoZIhvcNAQEFBQADQQBJlffJHybjDGxRMqaRmDhX0+6v02TUKZsW
r5QuVbpQhH6u+0UgcW0jp9QwpxoPTLTWGXEWBBBurxFwiCBhkQ+V
-----END CERTIFICATE-----
`

	var rsaKeyPEM = testingKey(`-----BEGIN RSA TESTING KEY-----
MIIBOwIBAAJBANLJhPHhITqQbPklG3ibCVxwGMRfp/v4XqhfdQHdcVfHap6NQ5Wo
k/4xIA+ui35/MmNartNuC+BdZ1tMuVCPFZcCAwEAAQJAEJ2N+zsR0Xn8/Q6twa4G
6OB1M1WO+k+ztnX/1SvNeWu8D6GImtupLTYgjZcHufykj09jiHmjHx8u8ZZB/o1N
MQIhAPW+eyZo7ay3lMz1V01WVjNKK9QSn1MJlb06h/LuYv9FAiEA25WPedKgVyCW
SmUwbPw8fnTcpqDWE3yTO3vKcebqMSsCIBF3UmVue8YU3jybC3NxuXq3wNm34R8T
xVLHwDXh/6NJAiEAl2oHGGLz64BuAfjKrqwz7qMYr9HCLIe/YsoWq/olzScCIQDi
D2lWusoe2/nEqfDVVWGWlyJ7yOmqaVm/iNUN9B2N2g==
-----END RSA TESTING KEY-----
`)

	// keyPEM is the same as rsaKeyPEM, but declares itself as just
	// "PRIVATE KEY", not "RSA PRIVATE KEY".  https://golang.org/issue/4477
	var keyPEM = testingKey(`-----BEGIN TESTING KEY-----
MIIBOwIBAAJBANLJhPHhITqQbPklG3ibCVxwGMRfp/v4XqhfdQHdcVfHap6NQ5Wo
k/4xIA+ui35/MmNartNuC+BdZ1tMuVCPFZcCAwEAAQJAEJ2N+zsR0Xn8/Q6twa4G
6OB1M1WO+k+ztnX/1SvNeWu8D6GImtupLTYgjZcHufykj09jiHmjHx8u8ZZB/o1N
MQIhAPW+eyZo7ay3lMz1V01WVjNKK9QSn1MJlb06h/LuYv9FAiEA25WPedKgVyCW
SmUwbPw8fnTcpqDWE3yTO3vKcebqMSsCIBF3UmVue8YU3jybC3NxuXq3wNm34R8T
xVLHwDXh/6NJAiEAl2oHGGLz64BuAfjKrqwz7qMYr9HCLIe/YsoWq/olzScCIQDi
D2lWusoe2/nEqfDVVWGWlyJ7yOmqaVm/iNUN9B2N2g==
-----END TESTING KEY-----
`)

	var ecdsaCertPEM = `-----BEGIN CERTIFICATE-----
MIIB/jCCAWICCQDscdUxw16XFDAJBgcqhkjOPQQBMEUxCzAJBgNVBAYTAkFVMRMw
EQYDVQQIEwpTb21lLVN0YXRlMSEwHwYDVQQKExhJbnRlcm5ldCBXaWRnaXRzIFB0
eSBMdGQwHhcNMTIxMTE0MTI0MDQ4WhcNMTUxMTE0MTI0MDQ4WjBFMQswCQYDVQQG
EwJBVTETMBEGA1UECBMKU29tZS1TdGF0ZTEhMB8GA1UEChMYSW50ZXJuZXQgV2lk
Z2l0cyBQdHkgTHRkMIGbMBAGByqGSM49AgEGBSuBBAAjA4GGAAQBY9+my9OoeSUR
lDQdV/x8LsOuLilthhiS1Tz4aGDHIPwC1mlvnf7fg5lecYpMCrLLhauAc1UJXcgl
01xoLuzgtAEAgv2P/jgytzRSpUYvgLBt1UA0leLYBy6mQQbrNEuqT3INapKIcUv8
XxYP0xMEUksLPq6Ca+CRSqTtrd/23uTnapkwCQYHKoZIzj0EAQOBigAwgYYCQXJo
A7Sl2nLVf+4Iu/tAX/IF4MavARKC4PPHK3zfuGfPR3oCCcsAoz3kAzOeijvd0iXb
H5jBImIxPL4WxQNiBTexAkF8D1EtpYuWdlVQ80/h/f4pBcGiXPqX5h2PQSQY7hP1
+jwM1FGS4fREIOvlBYr/SzzQRtwrvrzGYxDEDbsC0ZGRnA==
-----END CERTIFICATE-----
`

	var ecdsaKeyPEM = testingKey(`-----BEGIN EC PARAMETERS-----
BgUrgQQAIw==
-----END EC PARAMETERS-----
-----BEGIN EC TESTING KEY-----
MIHcAgEBBEIBrsoKp0oqcv6/JovJJDoDVSGWdirrkgCWxrprGlzB9o0X8fV675X0
NwuBenXFfeZvVcwluO7/Q9wkYoPd/t3jGImgBwYFK4EEACOhgYkDgYYABAFj36bL
06h5JRGUNB1X/Hwuw64uKW2GGJLVPPhoYMcg/ALWaW+d/t+DmV5xikwKssuFq4Bz
VQldyCXTXGgu7OC0AQCC/Y/+ODK3NFKlRi+AsG3VQDSV4tgHLqZBBus0S6pPcg1q
kohxS/xfFg/TEwRSSws+roJr4JFKpO2t3/be5OdqmQ==
-----END EC TESTING KEY-----
`)

	type test struct {
		algo string
		cert string
		key  string
	}
	var keyPairTests = []test{
		{"ECDSA", ecdsaCertPEM, ecdsaKeyPEM},
		{"RSA", rsaCertPEM, rsaKeyPEM},
		{"RSA-untyped", rsaCertPEM, keyPEM}, // golang.org/issue/4477
	}

	if fips140.Version() != "v1.0.0" {
		keyPairTests = append(keyPairTests,
			test{"ML-DSA-44", testMLDSA44CertPEM, testingKey(testMLDSA44KeyPEM)},
			test{"ML-DSA-65", testMLDSA65CertPEM, testingKey(testMLDSA65KeyPEM)},
			test{"ML-DSA-87", testMLDSA87CertPEM, testingKey(testMLDSA87KeyPEM)},
		)
	}

	t.Parallel()
	var pem []byte
	for _, test := range keyPairTests {
		pem = []byte(test.cert + test.key)
		if _, err := X509KeyPair(pem, pem); err != nil {
			t.Errorf("Failed to load %s cert followed by %s key: %s", test.algo, test.algo, err)
		}
		pem = []byte(test.key + test.cert)
		if _, err := X509KeyPair(pem, pem); err != nil {
			t.Errorf("Failed to load %s key followed by %s cert: %s", test.algo, test.algo, err)
		}
	}

	_, err := X509KeyPair([]byte(rsaKeyPEM), []byte(rsaCertPEM))
	if err == nil {
		t.Fatalf("X509KeyPair didn't return an error when arguments were switched")
	}
	if subStr := "been switched"; !strings.Contains(err.Error(), subStr) {
		t.Fatalf("Expected %q in the error when switching arguments to X509KeyPair, but the error was %q", subStr, err)
	}

	_, err = X509KeyPair([]byte(rsaCertPEM), []byte(rsaCertPEM))
	if err == nil {
		t.Fatalf("X509KeyPair didn't return an error when both arguments were certificates")
	}
	if subStr := "certificate"; !strings.Contains(err.Error(), subStr) {
		t.Fatalf("Expected %q in the error when both arguments to X509KeyPair were certificates, but the error was %q", subStr, err)
	}

	const nonsensePEM = `
-----BEGIN NONSENSE-----
Zm9vZm9vZm9v
-----END NONSENSE-----
`

	_, err = X509KeyPair([]byte(nonsensePEM), []byte(nonsensePEM))
	if err == nil {
		t.Fatalf("X509KeyPair didn't return an error when both arguments were nonsense")
	}
	if subStr := "NONSENSE"; !strings.Contains(err.Error(), subStr) {
		t.Fatalf("Expected %q in the error when both arguments to X509KeyPair were nonsense, but the error was %q", subStr, err)
	}

	if _, err := X509KeyPair([]byte(rsaCertPEM), []byte(ecdsaKeyPEM)); err == nil {
		t.Error("Load of RSA certificate succeeded with ECDSA private key")
	}
	if _, err := X509KeyPair([]byte(ecdsaCertPEM), []byte(rsaKeyPEM)); err == nil {
		t.Error("Load of ECDSA certificate succeeded with RSA private key")
	}
}

func newLocalListener(t testing.TB) net.Listener {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		ln, err = net.Listen("tcp6", "[::1]:0")
	}
	if err != nil {
		t.Fatal(err)
	}
	return ln
}

func runWithFIPSEnabled(t *testing.T, testFunc func(t *testing.T)) {
	originalFIPS := fips140tls.Required()
	defer func() {
		if originalFIPS {
			fips140tls.Force()
		} else {
			fips140tls.TestingOnlyAbandon()
		}
	}()

	fips140tls.Force()
	t.Run("fips140tls", testFunc)
}

func runWithFIPSDisabled(t *testing.T, testFunc func(t *testing.T)) {
	if fips140.Enforced() {
		t.Run("no-fips140tls", func(t *testing.T) {
			t.Skip("can't run no-fips140tls tests in fips140=only mode")
		})
		return
	}

	originalFIPS := fips140tls.Required()
	defer func() {
		if originalFIPS {
			fips140tls.Force()
		} else {
			fips140tls.TestingOnlyAbandon()
		}
	}()

	fips140tls.TestingOnlyAbandon()
	t.Run("no-fips140tls", testFunc)
}

func skipFIPS(t *testing.T) {
	if fips140tls.Required() {
		t.Skip("skipping test in FIPS mode")
	}
}

func TestDialTimeout(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping in short mode")
	}

	timeout := 100 * time.Microsecond
	for !t.Failed() {
		acceptc := make(chan net.Conn)
		listener := newLocalListener(t)
		go func() {
			for {
				conn, err := listener.Accept()
				if err != nil {
					close(acceptc)
					return
				}
				acceptc <- conn
			}
		}()

		addr := listener.Addr().String()
		dialer := &net.Dialer{
			Timeout: timeout,
		}
		if conn, err := DialWithDialer(dialer, "tcp", addr, nil); err == nil {
			conn.Close()
			t.Errorf("DialWithTimeout unexpectedly completed successfully")
		} else if !isTimeoutError(err) {
			t.Errorf("resulting error not a timeout: %v\nType %T: %#v", err, err, err)
		}

		listener.Close()

		// We're looking for a timeout during the handshake, so check that the
		// Listener actually accepted the connection to initiate it. (If the server
		// takes too long to accept the connection, we might cancel before the
		// underlying net.Conn is ever dialed — without ever attempting a
		// handshake.)
		lconn, ok := <-acceptc
		if ok {
			// The Listener accepted a connection, so assume that it was from our
			// Dial: we triggered the timeout at the point where we wanted it!
			t.Logf("Listener accepted a connection from %s", lconn.RemoteAddr())
			lconn.Close()
		}
		// Close any spurious extra connections from the listener. (This is
		// possible if there are, for example, stray Dial calls from other tests.)
		for extraConn := range acceptc {
			t.Logf("spurious extra connection from %s", extraConn.RemoteAddr())
			extraConn.Close()
		}
		if ok {
			break
		}

		t.Logf("with timeout %v, DialWithDialer returned before listener accepted any connections; retrying", timeout)
		timeout *= 2
	}
}

func TestDeadlineOnWrite(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping in short mode")
	}

	ln := newLocalListener(t)
	defer ln.Close()

	srvCh := make(chan *Conn, 1)

	go func() {
		sconn, err := ln.Accept()
		if err != nil {
			srvCh <- nil
			return
		}
		srv := Server(sconn, testConfigServer.Clone())
		if err := srv.Handshake(); err != nil {
			srvCh <- nil
			return
		}
		srvCh <- srv
	}()

	clientConfig := testConfigClient.Clone()
	clientConfig.MaxVersion = VersionTLS12
	conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	srv := <-srvCh
	if srv == nil {
		t.Error(err)
	}

	// Make sure the client/server is setup correctly and is able to do a typical Write/Read
	buf := make([]byte, 6)
	if _, err := srv.Write([]byte("foobar")); err != nil {
		t.Errorf("Write err: %v", err)
	}
	if n, err := conn.Read(buf); n != 6 || err != nil || string(buf) != "foobar" {
		t.Errorf("Read = %d, %v, data %q; want 6, nil, foobar", n, err, buf)
	}

	// Set a deadline which should cause Write to timeout
	if err = srv.SetDeadline(time.Now()); err != nil {
		t.Fatalf("SetDeadline(time.Now()) err: %v", err)
	}
	if _, err = srv.Write([]byte("should fail")); err == nil {
		t.Fatal("Write should have timed out")
	}

	// Clear deadline and make sure it still times out
	if err = srv.SetDeadline(time.Time{}); err != nil {
		t.Fatalf("SetDeadline(time.Time{}) err: %v", err)
	}
	if _, err = srv.Write([]byte("This connection is permanently broken")); err == nil {
		t.Fatal("Write which previously failed should still time out")
	}

	// Verify the error
	if ne := err.(net.Error); ne.Temporary() != false {
		t.Error("Write timed out but incorrectly classified the error as Temporary")
	}
	if !isTimeoutError(err) {
		t.Error("Write timed out but did not classify the error as a Timeout")
	}
}

type readerFunc func([]byte) (int, error)

func (f readerFunc) Read(b []byte) (int, error) { return f(b) }

// TestDialer tests that tls.Dialer.DialContext can abort in the middle of a handshake.
// (The other cases are all handled by the existing dial tests in this package, which
// all also flow through the same code shared code paths)
func TestDialer(t *testing.T) {
	ln := newLocalListener(t)
	defer ln.Close()

	unblockServer := make(chan struct{}) // close-only
	defer close(unblockServer)
	go func() {
		conn, err := ln.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		<-unblockServer
	}()

	ctx, cancel := context.WithCancel(context.Background())
	d := Dialer{Config: &Config{
		Rand: readerFunc(func(b []byte) (n int, err error) {
			// By the time crypto/tls wants randomness, that means it has a TCP
			// connection, so we're past the Dialer's dial and now blocked
			// in a handshake. Cancel our context and see if we get unstuck.
			// (Our TCP listener above never reads or writes, so the Handshake
			// would otherwise be stuck forever)
			cancel()
			return len(b), nil
		}),
		ServerName: "foo",
	}}
	_, err := d.DialContext(ctx, "tcp", ln.Addr().String())
	if err != context.Canceled {
		t.Errorf("err = %v; want context.Canceled", err)
	}
}

func isTimeoutError(err error) bool {
	if ne, ok := err.(net.Error); ok {
		return ne.Timeout()
	}
	return false
}

// tests that Conn.Read returns (non-zero, io.EOF) instead of
// (non-zero, nil) when a Close (alertCloseNotify) is sitting right
// behind the application data in the buffer.
func TestConnReadNonzeroAndEOF(t *testing.T) {
	// This test is racy: it assumes that after a write to a
	// localhost TCP connection, the peer TCP connection can
	// immediately read it. Because it's racy, we skip this test
	// in short mode, and then retry it several times with an
	// increasing sleep in between our final write (via srv.Close
	// below) and the following read.
	if testing.Short() {
		t.Skip("skipping in short mode")
	}
	var err error
	for delay := time.Millisecond; delay <= 64*time.Millisecond; delay *= 2 {
		if err = testConnReadNonzeroAndEOF(t, delay); err == nil {
			return
		}
	}
	t.Error(err)
}

func testConnReadNonzeroAndEOF(t *testing.T, delay time.Duration) error {
	ln := newLocalListener(t)
	defer ln.Close()

	srvCh := make(chan *Conn, 1)
	var serr error
	go func() {
		sconn, err := ln.Accept()
		if err != nil {
			serr = err
			srvCh <- nil
			return
		}
		serverConfig := testConfigServer.Clone()
		srv := Server(sconn, serverConfig)
		if err := srv.Handshake(); err != nil {
			serr = fmt.Errorf("handshake: %v", err)
			srvCh <- nil
			return
		}
		srvCh <- srv
	}()

	clientConfig := testConfigClient.Clone()
	// In TLS 1.3, alerts are encrypted and disguised as application data, so
	// the opportunistic peek won't work.
	clientConfig.MaxVersion = VersionTLS12
	conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	srv := <-srvCh
	if srv == nil {
		return serr
	}

	buf := make([]byte, 6)

	srv.Write([]byte("foobar"))
	n, err := conn.Read(buf)
	if n != 6 || err != nil || string(buf) != "foobar" {
		return fmt.Errorf("Read = %d, %v, data %q; want 6, nil, foobar", n, err, buf)
	}

	srv.Write([]byte("abcdef"))
	srv.Close()
	time.Sleep(delay)
	n, err = conn.Read(buf)
	if n != 6 || string(buf) != "abcdef" {
		return fmt.Errorf("Read = %d, buf= %q; want 6, abcdef", n, buf)
	}
	if err != io.EOF {
		return fmt.Errorf("Second Read error = %v; want io.EOF", err)
	}
	return nil
}

func TestTLSUniqueMatches(t *testing.T) {
	ln := newLocalListener(t)
	defer ln.Close()

	serverConfig := testConfigServer.Clone()
	serverConfig.MaxVersion = VersionTLS12 // TLSUnique is not defined in TLS 1.3

	serverTLSUniques := make(chan []byte)
	parentDone := make(chan struct{})
	childDone := make(chan struct{})
	defer close(parentDone)
	go func() {
		defer close(childDone)
		for i := 0; i < 2; i++ {
			sconn, err := ln.Accept()
			if err != nil {
				t.Error(err)
				return
			}
			srv := Server(sconn, serverConfig)
			if err := srv.Handshake(); err != nil {
				t.Error(err)
				return
			}
			select {
			case <-parentDone:
				return
			case serverTLSUniques <- srv.ConnectionState().TLSUnique:
			}
		}
	}()

	clientConfig := testConfigClient.Clone()
	clientConfig.ClientSessionCache = NewLRUClientSessionCache(1)
	conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
	if err != nil {
		t.Fatal(err)
	}

	var serverTLSUniquesValue []byte
	select {
	case <-childDone:
		return
	case serverTLSUniquesValue = <-serverTLSUniques:
	}

	if !bytes.Equal(conn.ConnectionState().TLSUnique, serverTLSUniquesValue) {
		t.Error("client and server channel bindings differ")
	}
	if serverTLSUniquesValue == nil || bytes.Equal(serverTLSUniquesValue, make([]byte, 12)) {
		t.Error("tls-unique is empty or zero")
	}
	conn.Close()

	conn, err = Dial("tcp", ln.Addr().String(), clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if !conn.ConnectionState().DidResume {
		t.Error("second session did not use resumption")
	}

	select {
	case <-childDone:
		return
	case serverTLSUniquesValue = <-serverTLSUniques:
	}

	if !bytes.Equal(conn.ConnectionState().TLSUnique, serverTLSUniquesValue) {
		t.Error("client and server channel bindings differ when session resumption is used")
	}
	if serverTLSUniquesValue == nil || bytes.Equal(serverTLSUniquesValue, make([]byte, 12)) {
		t.Error("resumption tls-unique is empty or zero")
	}
}

func TestVerifyHostname(t *testing.T) {
	testenv.MustHaveExternalNetwork(t)

	c, err := Dial("tcp", "www.google.com:https", nil)
	if err != nil {
		t.Fatal(err)
	}
	if err := c.VerifyHostname("www.google.com"); err != nil {
		t.Fatalf("verify www.google.com: %v", err)
	}
	if err := c.VerifyHostname("www.yahoo.com"); err == nil {
		t.Fatalf("verify www.yahoo.com succeeded")
	}

	c, err = Dial("tcp", "www.google.com:https", &Config{InsecureSkipVerify: true})
	if err != nil {
		t.Fatal(err)
	}
	if err := c.VerifyHostname("www.google.com"); err == nil {
		t.Fatalf("verify www.google.com succeeded with InsecureSkipVerify=true")
	}
}

func TestRealResumption(t *testing.T) {
	testenv.MustHaveExternalNetwork(t)

	config := &Config{
		ServerName:         "yahoo.com",
		ClientSessionCache: NewLRUClientSessionCache(0),
	}

	for range 10 {
		conn, err := Dial("tcp", "yahoo.com:443", config)
		if err != nil {
			t.Log("Dial error:", err)
			continue
		}
		// Do a read to consume the NewSessionTicket messages.
		fmt.Fprintf(conn, "GET / HTTP/1.1\r\nHost: yahoo.com\r\nConnection: close\r\n\r\n")
		conn.Read(make([]byte, 4096))
		conn.Close()

		conn, err = Dial("tcp", "yahoo.com:443", config)
		if err != nil {
			t.Log("second Dial error:", err)
			continue
		}
		state := conn.ConnectionState()
		conn.Close()

		if state.DidResume {
			return
		}
	}

	t.Fatal("no connection used session resumption")
}

func TestConnCloseBreakingWrite(t *testing.T) {
	ln := newLocalListener(t)
	defer ln.Close()

	srvCh := make(chan *Conn, 1)
	var serr error
	var sconn net.Conn
	go func() {
		var err error
		sconn, err = ln.Accept()
		if err != nil {
			serr = err
			srvCh <- nil
			return
		}
		serverConfig := testConfigServer.Clone()
		srv := Server(sconn, serverConfig)
		if err := srv.Handshake(); err != nil {
			serr = fmt.Errorf("handshake: %v", err)
			srvCh <- nil
			return
		}
		srvCh <- srv
	}()

	cconn, err := net.Dial("tcp", ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer cconn.Close()

	conn := &changeImplConn{
		Conn: cconn,
	}

	clientConfig := testConfigClient.Clone()
	tconn := Client(conn, clientConfig)
	if err := tconn.Handshake(); err != nil {
		t.Fatal(err)
	}

	srv := <-srvCh
	if srv == nil {
		t.Fatal(serr)
	}
	defer sconn.Close()

	connClosed := make(chan struct{})
	conn.closeFunc = func() error {
		close(connClosed)
		return nil
	}

	inWrite := make(chan bool, 1)
	var errConnClosed = errors.New("conn closed for test")
	conn.writeFunc = func(p []byte) (n int, err error) {
		inWrite <- true
		<-connClosed
		return 0, errConnClosed
	}

	closeReturned := make(chan bool, 1)
	go func() {
		<-inWrite
		tconn.Close() // test that this doesn't block forever.
		closeReturned <- true
	}()

	_, err = tconn.Write([]byte("foo"))
	if err != errConnClosed {
		t.Errorf("Write error = %v; want errConnClosed", err)
	}

	<-closeReturned
	if err := tconn.Close(); err != net.ErrClosed {
		t.Errorf("Close error = %v; want net.ErrClosed", err)
	}
}

func TestConnCloseWrite(t *testing.T) {
	ln := newLocalListener(t)
	defer ln.Close()

	clientDoneChan := make(chan struct{})

	serverCloseWrite := func() error {
		sconn, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("accept: %v", err)
		}
		defer sconn.Close()

		serverConfig := testConfigServer.Clone()
		srv := Server(sconn, serverConfig)
		if err := srv.Handshake(); err != nil {
			return fmt.Errorf("handshake: %v", err)
		}
		defer srv.Close()

		data, err := io.ReadAll(srv)
		if err != nil {
			return err
		}
		if len(data) > 0 {
			return fmt.Errorf("Read data = %q; want nothing", data)
		}

		if err := srv.CloseWrite(); err != nil {
			return fmt.Errorf("server CloseWrite: %v", err)
		}

		// Wait for clientCloseWrite to finish, so we know we
		// tested the CloseWrite before we defer the
		// sconn.Close above, which would also cause the
		// client to unblock like CloseWrite.
		<-clientDoneChan
		return nil
	}

	clientCloseWrite := func() error {
		defer close(clientDoneChan)

		clientConfig := testConfigClient.Clone()
		conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
		if err != nil {
			return err
		}
		if err := conn.Handshake(); err != nil {
			return err
		}
		defer conn.Close()

		if err := conn.CloseWrite(); err != nil {
			return fmt.Errorf("client CloseWrite: %v", err)
		}

		if _, err := conn.Write([]byte{0}); err != errShutdown {
			return fmt.Errorf("CloseWrite error = %v; want errShutdown", err)
		}

		data, err := io.ReadAll(conn)
		if err != nil {
			return err
		}
		if len(data) > 0 {
			return fmt.Errorf("Read data = %q; want nothing", data)
		}
		return nil
	}

	errChan := make(chan error, 2)

	go func() { errChan <- serverCloseWrite() }()
	go func() { errChan <- clientCloseWrite() }()

	for i := 0; i < 2; i++ {
		select {
		case err := <-errChan:
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(10 * time.Second):
			t.Fatal("deadlock")
		}
	}

	// Also test CloseWrite being called before the handshake is
	// finished:
	{
		ln2 := newLocalListener(t)
		defer ln2.Close()

		netConn, err := net.Dial("tcp", ln2.Addr().String())
		if err != nil {
			t.Fatal(err)
		}
		defer netConn.Close()
		conn := Client(netConn, testConfigClient.Clone())

		if err := conn.CloseWrite(); err != errEarlyCloseWrite {
			t.Errorf("CloseWrite error = %v; want errEarlyCloseWrite", err)
		}
	}
}

func TestWarningAlertFlood(t *testing.T) {
	ln := newLocalListener(t)
	defer ln.Close()

	server := func() error {
		sconn, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("accept: %v", err)
		}
		defer sconn.Close()

		serverConfig := testConfigServer.Clone()
		srv := Server(sconn, serverConfig)
		if err := srv.Handshake(); err != nil {
			return fmt.Errorf("handshake: %v", err)
		}
		defer srv.Close()

		_, err = io.ReadAll(srv)
		if err == nil {
			return errors.New("unexpected lack of error from server")
		}
		const expected = "too many ignored"
		if str := err.Error(); !strings.Contains(str, expected) {
			return fmt.Errorf("expected error containing %q, but saw: %s", expected, str)
		}

		return nil
	}

	errChan := make(chan error, 1)
	go func() { errChan <- server() }()

	clientConfig := testConfigClient.Clone()
	clientConfig.MaxVersion = VersionTLS12 // there are no warning alerts in TLS 1.3
	conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if err := conn.Handshake(); err != nil {
		t.Fatal(err)
	}

	for i := 0; i < maxUselessRecords+1; i++ {
		conn.sendAlert(alertNoRenegotiation)
	}

	if err := <-errChan; err != nil {
		t.Fatal(err)
	}
}

func TestCloneFuncFields(t *testing.T) {
	const expectedCount = 10
	called := 0

	c1 := Config{
		Time: func() time.Time {
			called |= 1 << 0
			return time.Time{}
		},
		GetCertificate: func(*ClientHelloInfo) (*Certificate, error) {
			called |= 1 << 1
			return nil, nil
		},
		GetClientCertificate: func(*CertificateRequestInfo) (*Certificate, error) {
			called |= 1 << 2
			return nil, nil
		},
		GetConfigForClient: func(*ClientHelloInfo) (*Config, error) {
			called |= 1 << 3
			return nil, nil
		},
		VerifyPeerCertificate: func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
			called |= 1 << 4
			return nil
		},
		VerifyConnection: func(ConnectionState) error {
			called |= 1 << 5
			return nil
		},
		UnwrapSession: func(identity []byte, cs ConnectionState) (*SessionState, error) {
			called |= 1 << 6
			return nil, nil
		},
		WrapSession: func(cs ConnectionState, ss *SessionState) ([]byte, error) {
			called |= 1 << 7
			return nil, nil
		},
		EncryptedClientHelloRejectionVerify: func(ConnectionState) error {
			called |= 1 << 8
			return nil
		},
		GetEncryptedClientHelloKeys: func(*ClientHelloInfo) ([]EncryptedClientHelloKey, error) {
			called |= 1 << 9
			return nil, nil
		},
	}

	c2 := c1.Clone()

	c2.Time()
	c2.GetCertificate(nil)
	c2.GetClientCertificate(nil)
	c2.GetConfigForClient(nil)
	c2.VerifyPeerCertificate(nil, nil)
	c2.VerifyConnection(ConnectionState{})
	c2.UnwrapSession(nil, ConnectionState{})
	c2.WrapSession(ConnectionState{}, nil)
	c2.EncryptedClientHelloRejectionVerify(ConnectionState{})
	c2.GetEncryptedClientHelloKeys(nil)

	if called != (1<<expectedCount)-1 {
		t.Fatalf("expected %d calls but saw calls %b", expectedCount, called)
	}
}

func TestCloneNonFuncFields(t *testing.T) {
	var c1 Config
	v := reflect.ValueOf(&c1).Elem()

	typ := v.Type()
	for i := 0; i < typ.NumField(); i++ {
		f := v.Field(i)
		// testing/quick can't handle functions or interfaces and so
		// isn't used here.
		switch fn := typ.Field(i).Name; fn {
		case "Rand":
			f.Set(reflect.ValueOf(io.Reader(os.Stdin)))
		case "Time", "GetCertificate", "GetConfigForClient", "VerifyPeerCertificate", "VerifyConnection", "GetClientCertificate", "WrapSession", "UnwrapSession", "EncryptedClientHelloRejectionVerify", "GetEncryptedClientHelloKeys":
			// DeepEqual can't compare functions. If you add a
			// function field to this list, you must also change
			// TestCloneFuncFields to ensure that the func field is
			// cloned.
		case "Certificates":
			f.Set(reflect.ValueOf([]Certificate{
				{Certificate: [][]byte{{'b'}}},
			}))
		case "NameToCertificate":
			f.Set(reflect.ValueOf(map[string]*Certificate{"a": nil}))
		case "RootCAs", "ClientCAs":
			f.Set(reflect.ValueOf(x509.NewCertPool()))
		case "ClientSessionCache":
			f.Set(reflect.ValueOf(NewLRUClientSessionCache(10)))
		case "KeyLogWriter":
			f.Set(reflect.ValueOf(io.Writer(os.Stdout)))
		case "NextProtos":
			f.Set(reflect.ValueOf([]string{"a", "b"}))
		case "ServerName":
			f.Set(reflect.ValueOf("b"))
		case "ClientAuth":
			f.Set(reflect.ValueOf(VerifyClientCertIfGiven))
		case "InsecureSkipVerify", "InsecureSkipTimeVerify", "SessionTicketsDisabled", "DynamicRecordSizingDisabled", "PreferServerCipherSuites", "OmitEmptyPsk", "PreferSkipResumptionOnNilExtension", "AlwaysIncludePSK":
			f.Set(reflect.ValueOf(true))
		case "InsecureServerNameToVerify": // [uTLS]
			f.Set(reflect.ValueOf("c"))
		case "PQSignatureSchemesEnabled": // [uTLS]
			f.Set(reflect.ValueOf(true))
		case "ApplicationSettings": // [uTLS] ALPS
			f.Set(reflect.ValueOf(map[string][]byte{"a": {1}}))
		case "MinVersion", "MaxVersion":
			f.Set(reflect.ValueOf(uint16(VersionTLS12)))
		case "SessionTicketKey":
			f.Set(reflect.ValueOf([32]byte{}))
		case "CipherSuites":
			f.Set(reflect.ValueOf([]uint16{1, 2}))
		case "CurvePreferences":
			f.Set(reflect.ValueOf([]CurveID{CurveP256}))
		case "Renegotiation":
			f.Set(reflect.ValueOf(RenegotiateOnceAsClient))
		case "EncryptedClientHelloConfigList":
			f.Set(reflect.ValueOf([]byte{'x'}))
		case "EncryptedClientHelloKeys":
			f.Set(reflect.ValueOf([]EncryptedClientHelloKey{
				{Config: []byte{1}, PrivateKey: []byte{1}},
			}))
		case "mutex", "autoSessionTicketKeys", "sessionTicketKeys":
			continue // these are unexported fields that are handled separately
		default:
			t.Errorf("all fields must be accounted for, but saw unknown field %q", fn)
		}
	}
	// Set the unexported fields related to session ticket keys, which are copied with Clone().
	c1.autoSessionTicketKeys = []ticketKey{c1.ticketKeyFromBytes(c1.SessionTicketKey)}
	c1.sessionTicketKeys = []ticketKey{c1.ticketKeyFromBytes(c1.SessionTicketKey)}

	c2 := c1.Clone()
	if !reflect.DeepEqual(&c1, c2) {
		t.Errorf("clone failed to copy a field")
	}
}

func TestCloneNilConfig(t *testing.T) {
	var config *Config
	if cc := config.Clone(); cc != nil {
		t.Fatalf("Clone with nil should return nil, got: %+v", cc)
	}
}

// changeImplConn is a net.Conn which can change its Write and Close
// methods.
type changeImplConn struct {
	net.Conn
	writeFunc func([]byte) (int, error)
	closeFunc func() error
}

func (w *changeImplConn) Write(p []byte) (n int, err error) {
	if w.writeFunc != nil {
		return w.writeFunc(p)
	}
	return w.Conn.Write(p)
}

func (w *changeImplConn) Close() error {
	if w.closeFunc != nil {
		return w.closeFunc()
	}
	return w.Conn.Close()
}

func throughput(b *testing.B, version uint16, totalBytes int64, dynamicRecordSizingDisabled bool) {
	ln := newLocalListener(b)
	defer ln.Close()

	N := b.N

	// Less than 64KB because Windows appears to use a TCP rwin < 64KB.
	// See Issue #15899.
	const bufsize = 32 << 10

	go func() {
		buf := make([]byte, bufsize)
		for i := 0; i < N; i++ {
			sconn, err := ln.Accept()
			if err != nil {
				// panic rather than synchronize to avoid benchmark overhead
				// (cannot call b.Fatal in goroutine)
				panic(fmt.Errorf("accept: %v", err))
			}
			serverConfig := testConfigServer.Clone()
			serverConfig.CipherSuites = nil // the defaults may prefer faster ciphers
			serverConfig.DynamicRecordSizingDisabled = dynamicRecordSizingDisabled
			srv := Server(sconn, serverConfig)
			if err := srv.Handshake(); err != nil {
				panic(fmt.Errorf("handshake: %v", err))
			}
			if _, err := io.CopyBuffer(srv, srv, buf); err != nil {
				panic(fmt.Errorf("copy buffer: %v", err))
			}
		}
	}()

	b.SetBytes(totalBytes)
	clientConfig := testConfigClient.Clone()
	clientConfig.CipherSuites = nil // the defaults may prefer faster ciphers
	clientConfig.DynamicRecordSizingDisabled = dynamicRecordSizingDisabled
	clientConfig.MaxVersion = version

	buf := make([]byte, bufsize)
	chunks := int(math.Ceil(float64(totalBytes) / float64(len(buf))))
	for i := 0; i < N; i++ {
		conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
		if err != nil {
			b.Fatal(err)
		}
		for j := 0; j < chunks; j++ {
			_, err := conn.Write(buf)
			if err != nil {
				b.Fatal(err)
			}
			_, err = io.ReadFull(conn, buf)
			if err != nil {
				b.Fatal(err)
			}
		}
		conn.Close()
	}
}

func BenchmarkThroughput(b *testing.B) {
	for _, mode := range []string{"Max", "Dynamic"} {
		for size := 1; size <= 64; size <<= 1 {
			name := fmt.Sprintf("%sPacket/%dMB", mode, size)
			b.Run(name, func(b *testing.B) {
				b.Run("TLSv12", func(b *testing.B) {
					throughput(b, VersionTLS12, int64(size<<20), mode == "Max")
				})
				b.Run("TLSv13", func(b *testing.B) {
					throughput(b, VersionTLS13, int64(size<<20), mode == "Max")
				})
			})
		}
	}
}

type slowConn struct {
	net.Conn
	bps int
}

func (c *slowConn) Write(p []byte) (int, error) {
	if c.bps == 0 {
		panic("too slow")
	}
	t0 := time.Now()
	wrote := 0
	for wrote < len(p) {
		time.Sleep(100 * time.Microsecond)
		allowed := int(time.Since(t0).Seconds()*float64(c.bps)) / 8
		if allowed > len(p) {
			allowed = len(p)
		}
		if wrote < allowed {
			n, err := c.Conn.Write(p[wrote:allowed])
			wrote += n
			if err != nil {
				return wrote, err
			}
		}
	}
	return len(p), nil
}

func latency(b *testing.B, version uint16, bps int, dynamicRecordSizingDisabled bool) {
	ln := newLocalListener(b)
	defer ln.Close()

	N := b.N

	go func() {
		for i := 0; i < N; i++ {
			sconn, err := ln.Accept()
			if err != nil {
				// panic rather than synchronize to avoid benchmark overhead
				// (cannot call b.Fatal in goroutine)
				panic(fmt.Errorf("accept: %v", err))
			}
			serverConfig := testConfigServer.Clone()
			serverConfig.DynamicRecordSizingDisabled = dynamicRecordSizingDisabled
			srv := Server(&slowConn{sconn, bps}, serverConfig)
			if err := srv.Handshake(); err != nil {
				panic(fmt.Errorf("handshake: %v", err))
			}
			io.Copy(srv, srv)
		}
	}()

	clientConfig := testConfigClient.Clone()
	clientConfig.DynamicRecordSizingDisabled = dynamicRecordSizingDisabled
	clientConfig.MaxVersion = version

	buf := make([]byte, 16384)
	peek := make([]byte, 1)

	for i := 0; i < N; i++ {
		conn, err := Dial("tcp", ln.Addr().String(), clientConfig)
		if err != nil {
			b.Fatal(err)
		}
		// make sure we're connected and previous connection has stopped
		if _, err := conn.Write(buf[:1]); err != nil {
			b.Fatal(err)
		}
		if _, err := io.ReadFull(conn, peek); err != nil {
			b.Fatal(err)
		}
		if _, err := conn.Write(buf); err != nil {
			b.Fatal(err)
		}
		if _, err = io.ReadFull(conn, peek); err != nil {
			b.Fatal(err)
		}
		conn.Close()
	}
}

func BenchmarkLatency(b *testing.B) {
	for _, mode := range []string{"Max", "Dynamic"} {
		for _, kbps := range []int{200, 500, 1000, 2000, 5000} {
			name := fmt.Sprintf("%sPacket/%dkbps", mode, kbps)
			b.Run(name, func(b *testing.B) {
				b.Run("TLSv12", func(b *testing.B) {
					latency(b, VersionTLS12, kbps*1000, mode == "Max")
				})
				b.Run("TLSv13", func(b *testing.B) {
					latency(b, VersionTLS13, kbps*1000, mode == "Max")
				})
			})
		}
	}
}

func TestConnectionStateMarshal(t *testing.T) {
	cs := &ConnectionState{}
	_, err := json.Marshal(cs)
	if err != nil {
		t.Errorf("json.Marshal failed on ConnectionState: %v", err)
	}
}

func TestConnectionState(t *testing.T) {
	const alpnProtocol = "golang"
	const serverName = "test.golang.example"
	var scts = [][]byte{[]byte("dummy sct 1"), []byte("dummy sct 2")}
	var ocsp = []byte("dummy ocsp")

	checkConnectionState := func(t *testing.T, cs ConnectionState, version uint16, isClient bool) {
		// On the client, the peer is the server (testRSA2048Cert under
		// testRootCert); on the server, the peer is the client
		// (testClientRSA2048Cert under testClientRootCert).
		peerLeaf, peerRoot := testRSA2048Cert.Certificate[0], testRootCert.Certificate[0]
		if !isClient {
			peerLeaf, peerRoot = testClientRSA2048Cert.Certificate[0], testClientRootCert.Certificate[0]
		}
		if cs.Version != version {
			t.Errorf("got Version %x, expected %x", cs.Version, version)
		}

		if !cs.HandshakeComplete {
			t.Errorf("got HandshakeComplete %v, expected true", cs.HandshakeComplete)
		}

		if cs.DidResume {
			t.Errorf("got DidResume %v, expected false", cs.DidResume)
		}

		if cs.CipherSuite == 0 {
			t.Errorf("got zero CipherSuite")
		}

		if cs.CurveID == 0 {
			t.Errorf("got zero CurveID")
		}

		if cs.NegotiatedProtocol != alpnProtocol {
			t.Errorf("got ALPN protocol %q, expected %q", cs.NegotiatedProtocol, alpnProtocol)
		}

		if !cs.NegotiatedProtocolIsMutual {
			t.Errorf("got NegotiatedProtocolIsMutual %v, expected true", cs.NegotiatedProtocolIsMutual)
		}

		if cs.ServerName != serverName {
			t.Errorf("got ServerName %q, expected %q", cs.ServerName, serverName)
		}

		if len(cs.PeerCertificates) != 1 {
			t.Errorf("got %d PeerCertificates, expected %d", len(cs.PeerCertificates), 1)
		} else if !bytes.Equal(cs.PeerCertificates[0].Raw, peerLeaf) {
			t.Errorf("got PeerCertificates %x, expected %x", cs.PeerCertificates[0].Raw, peerLeaf)
		}

		if len(cs.VerifiedChains) != 1 {
			t.Errorf("got %d long verified chain, expected %d", len(cs.VerifiedChains), 1)
		} else if len(cs.VerifiedChains[0]) != 2 {
			t.Errorf("got %d verified chain, expected %d", len(cs.VerifiedChains[0]), 2)
		} else if !bytes.Equal(cs.VerifiedChains[0][0].Raw, peerLeaf) {
			t.Errorf("got verified chain[0][0] %x, expected %x", cs.VerifiedChains[0][0].Raw, peerLeaf)
		} else if !bytes.Equal(cs.VerifiedChains[0][1].Raw, peerRoot) {
			t.Errorf("got verified chain[0][1] %x, expected %x", cs.VerifiedChains[0][1].Raw, peerRoot)
		}

		// Only TLS 1.3 supports OCSP and SCTs on client certs.
		if isClient || version == VersionTLS13 {
			if len(cs.SignedCertificateTimestamps) != 2 {
				t.Errorf("got %d SCTs, expected %d", len(cs.SignedCertificateTimestamps), 2)
			} else if !bytes.Equal(cs.SignedCertificateTimestamps[0], scts[0]) {
				t.Errorf("got SCTs %x, expected %x", cs.SignedCertificateTimestamps[0], scts[0])
			} else if !bytes.Equal(cs.SignedCertificateTimestamps[1], scts[1]) {
				t.Errorf("got SCTs %x, expected %x", cs.SignedCertificateTimestamps[1], scts[1])
			}
			if !bytes.Equal(cs.OCSPResponse, ocsp) {
				t.Errorf("got OCSP %x, expected %x", cs.OCSPResponse, ocsp)
			}
		} else {
			if cs.SignedCertificateTimestamps != nil {
				t.Errorf("got %d SCTs, expected nil", len(cs.SignedCertificateTimestamps))
			}
			if cs.OCSPResponse != nil {
				t.Errorf("got OCSP %x, expected nil", cs.OCSPResponse)
			}
		}

		if version == VersionTLS13 {
			if cs.TLSUnique != nil {
				t.Errorf("got TLSUnique %x, expected nil", cs.TLSUnique)
			}
		} else {
			if cs.TLSUnique == nil {
				t.Errorf("got nil TLSUnique")
			}
		}
	}

	compareConnectionStates := func(t *testing.T, cs1, cs2 ConnectionState) {
		if cs1.Version != cs2.Version {
			t.Errorf("Version mismatch: %x != %x", cs1.Version, cs2.Version)
		}
		if cs1.HandshakeComplete != cs2.HandshakeComplete {
			t.Errorf("HandshakeComplete mismatch: %v != %v", cs1.HandshakeComplete, cs2.HandshakeComplete)
		}
		// DidResume is expected to be different.
		if cs1.CipherSuite != cs2.CipherSuite {
			t.Errorf("CipherSuite mismatch: %x != %x", cs1.CipherSuite, cs2.CipherSuite)
		}
		if cs1.CurveID != cs2.CurveID {
			t.Errorf("CurveID mismatch: %s != %s", cs1.CurveID, cs2.CurveID)
		}
		if cs1.NegotiatedProtocol != cs2.NegotiatedProtocol {
			t.Errorf("NegotiatedProtocol mismatch: %q != %q", cs1.NegotiatedProtocol, cs2.NegotiatedProtocol)
		}
		if cs1.NegotiatedProtocolIsMutual != cs2.NegotiatedProtocolIsMutual {
			t.Errorf("NegotiatedProtocolIsMutual mismatch: %v != %v", cs1.NegotiatedProtocolIsMutual, cs2.NegotiatedProtocolIsMutual)
		}
		if cs1.ServerName != cs2.ServerName {
			t.Errorf("ServerName mismatch: %q != %q", cs1.ServerName, cs2.ServerName)
		}
		if !reflect.DeepEqual(cs1.PeerCertificates, cs2.PeerCertificates) {
			t.Errorf("PeerCertificates mismatch")
		}
		if !reflect.DeepEqual(cs1.VerifiedChains, cs2.VerifiedChains) {
			t.Errorf("VerifiedChains mismatch")
		}
		if !reflect.DeepEqual(cs1.SignedCertificateTimestamps, cs2.SignedCertificateTimestamps) {
			t.Errorf("SignedCertificateTimestamps mismatch: %x != %x", cs1.SignedCertificateTimestamps, cs2.SignedCertificateTimestamps)
		}
		if !bytes.Equal(cs1.OCSPResponse, cs2.OCSPResponse) {
			t.Errorf("OCSPResponse mismatch: %x != %x", cs1.OCSPResponse, cs2.OCSPResponse)
		}
		// TLSUnique is expected to be different.
	}

	for _, v := range []uint16{VersionTLS10, VersionTLS12, VersionTLS13} {
		if !isFIPSVersion(v) && fips140tls.Required() {
			t.Skipf("skipping test in FIPS 140-3 mode for non-FIPS version %x", v)
		}
		var name string
		switch v {
		case VersionTLS10:
			name = "TLSv10"
		case VersionTLS12:
			name = "TLSv12"
		case VersionTLS13:
			name = "TLSv13"
		}
		t.Run(name, func(t *testing.T) {
			serverCert := testRSA2048Cert
			serverCert.SignedCertificateTimestamps = scts
			serverCert.OCSPStaple = ocsp
			clientCert := testClientRSA2048Cert
			clientCert.SignedCertificateTimestamps = scts
			clientCert.OCSPStaple = ocsp

			serverConfig := &Config{
				Time:         testTime,
				Certificates: []Certificate{serverCert},
				MinVersion:   v,
				MaxVersion:   v,
				ClientCAs:    testClientRootCertPool,
				ClientAuth:   RequireAndVerifyClientCert,
				NextProtos:   []string{alpnProtocol},
			}
			clientConfig := &Config{
				Time:               testTime,
				Certificates:       []Certificate{clientCert},
				MinVersion:         v,
				MaxVersion:         v,
				RootCAs:            testRootCertPool,
				NextProtos:         []string{alpnProtocol},
				ServerName:         serverName,
				ClientSessionCache: NewLRUClientSessionCache(1),
			}

			ss, cs, err := testHandshake(t, clientConfig, serverConfig)
			if err != nil {
				t.Fatalf("handshake failed: %v", err)
			}

			t.Run("Client", func(t *testing.T) { checkConnectionState(t, cs, v, true) })
			t.Run("Server", func(t *testing.T) { checkConnectionState(t, ss, v, false) })

			t.Run("Resume", func(t *testing.T) {
				// TODO: test changing parameters between original and resumed
				// connection when the protocol allows it.

				ss1, cs1, err := testHandshake(t, clientConfig, serverConfig)
				if err != nil {
					t.Fatalf("handshake failed: %v", err)
				}

				if !cs1.DidResume || !ss1.DidResume {
					t.Errorf("DidResume is false")
				}

				t.Run("Client", func(t *testing.T) { compareConnectionStates(t, cs, cs1) })
				t.Run("Server", func(t *testing.T) { compareConnectionStates(t, ss, ss1) })
			})
		})
	}
}

// Issue 28744: Ensure that we don't modify memory
// that Config doesn't own such as Certificates.
func TestBuildNameToCertificate_doesntModifyCertificates(t *testing.T) {
	config := testConfigServer.Clone()
	config.Certificates = []Certificate{testRSA2048Cert, testSNICert}

	config.BuildNameToCertificate()
	got := config.Certificates
	want := []Certificate{testRSA2048Cert, testSNICert}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("Certificates were mutated by BuildNameToCertificate\nGot: %#v\nWant: %#v\n", got, want)
	}
}

func testingKey(s string) string { return strings.ReplaceAll(s, "TESTING KEY", "PRIVATE KEY") }

func TestClientHelloInfo_SupportsCertificate(t *testing.T) {
	skipFIPS(t) // SHA-1, Ed25519, and legacy RSA kex test cases not FIPS compatible.

	pkcs1Cert := testRSA2048Cert
	pkcs1Cert.SupportedSignatureAlgorithms = []SignatureScheme{PKCS1WithSHA1, PKCS1WithSHA256}

	tests := []struct {
		c       Certificate
		chi     *ClientHelloInfo
		wantErr string
	}{
		{testRSA2048Cert, &ClientHelloInfo{
			ServerName:        "test.golang.example",
			SignatureSchemes:  []SignatureScheme{PSSWithSHA256},
			SupportedVersions: []uint16{VersionTLS13},
		}, ""},
		{testECDSAP256Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{PSSWithSHA256, ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS13, VersionTLS12},
		}, ""},
		{testRSA2048Cert, &ClientHelloInfo{
			ServerName:        "example.com",
			SignatureSchemes:  []SignatureScheme{PSSWithSHA256},
			SupportedVersions: []uint16{VersionTLS13},
		}, "not valid for requested server name"},
		{testECDSAP256Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{ECDSAWithP384AndSHA384},
			SupportedVersions: []uint16{VersionTLS13},
		}, "signature algorithms"},
		{pkcs1Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{PSSWithSHA256, ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS13},
		}, "signature algorithms"},

		{testRSA2048Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			SignatureSchemes:  []SignatureScheme{PKCS1WithSHA1},
			SupportedVersions: []uint16{VersionTLS13, VersionTLS12},
		}, "signature algorithms"},
		{testRSA2048Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			SignatureSchemes:  []SignatureScheme{PKCS1WithSHA1},
			SupportedVersions: []uint16{VersionTLS13, VersionTLS12},
			config: &Config{
				CipherSuites: []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
				MaxVersion:   VersionTLS12,
			},
		}, ""}, // Check that mutual version selection works.

		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS12},
		}, ""},
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP384AndSHA384},
			SupportedVersions: []uint16{VersionTLS12},
		}, ""}, // TLS 1.2 does not restrict curves based on the SignatureScheme.
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  nil,
			SupportedVersions: []uint16{VersionTLS12},
		}, ""}, // TLS 1.2 comes with default signature schemes.
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS12},
		}, "cipher suite"},
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS12},
			config: &Config{
				CipherSuites: []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			},
		}, "cipher suite"},
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP384},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS12},
		}, "certificate curve"},
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{1},
			SignatureSchemes:  []SignatureScheme{ECDSAWithP256AndSHA256},
			SupportedVersions: []uint16{VersionTLS12},
		}, "only incompatible point formats"},
		{testECDSAP256Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{PSSWithSHA256},
			SupportedVersions: []uint16{VersionTLS12},
		}, "signature algorithms"},

		{testEd25519Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256}, // only relevant for ECDHE support
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{Ed25519},
			SupportedVersions: []uint16{VersionTLS12},
		}, ""},
		{testEd25519Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256}, // only relevant for ECDHE support
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{Ed25519},
			SupportedVersions: []uint16{VersionTLS10},
			config:            &Config{MinVersion: VersionTLS10},
		}, "doesn't support Ed25519"},
		{testEd25519Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SignatureSchemes:  []SignatureScheme{Ed25519},
			SupportedVersions: []uint16{VersionTLS12},
		}, "doesn't support ECDHE"},

		{testRSA2048Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA},
			SupportedCurves:   []CurveID{CurveP256}, // only relevant for ECDHE support
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SupportedVersions: []uint16{VersionTLS10},
			config:            &Config{MinVersion: VersionTLS10},
		}, ""},
		{testRSA2048Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			SupportedVersions: []uint16{VersionTLS12},
			config: &Config{
				CipherSuites: []uint16{TLS_RSA_WITH_AES_128_GCM_SHA256},
			},
		}, ""}, // static RSA fallback

		{testMLDSA44Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{MLDSA44},
			SupportedVersions: []uint16{VersionTLS13},
		}, ""},
		{testMLDSA65Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{MLDSA65},
			SupportedVersions: []uint16{VersionTLS13},
		}, ""},
		{testMLDSA87Cert, &ClientHelloInfo{
			SignatureSchemes:  []SignatureScheme{MLDSA87},
			SupportedVersions: []uint16{VersionTLS13},
		}, ""},
		{testMLDSA44Cert, &ClientHelloInfo{
			CipherSuites:      []uint16{TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256},
			SupportedCurves:   []CurveID{CurveP256},
			SupportedPoints:   []uint8{pointFormatUncompressed},
			SupportedVersions: []uint16{VersionTLS12},
		}, "doesn't support ML-DSA"},
	}
	for i, tt := range tests {
		err := tt.chi.SupportsCertificate(&tt.c)
		switch {
		case tt.wantErr == "" && err != nil:
			t.Errorf("%d: unexpected error: %v", i, err)
		case tt.wantErr != "" && err == nil:
			t.Errorf("%d: unexpected success", i)
		case tt.wantErr != "" && !strings.Contains(err.Error(), tt.wantErr):
			t.Errorf("%d: got error %q, expected %q", i, err, tt.wantErr)
		}
	}
}

func TestCipherSuites(t *testing.T) {
	var lastID uint16
	for _, c := range CipherSuites() {
		if lastID > c.ID {
			t.Errorf("CipherSuites are not ordered by ID: got %#04x after %#04x", c.ID, lastID)
		} else {
			lastID = c.ID
		}

		if c.Insecure {
			t.Errorf("%#04x: Insecure CipherSuite returned by CipherSuites()", c.ID)
		}
	}
	lastID = 0
	for _, c := range InsecureCipherSuites() {
		if lastID > c.ID {
			t.Errorf("InsecureCipherSuites are not ordered by ID: got %#04x after %#04x", c.ID, lastID)
		} else {
			lastID = c.ID
		}

		if !c.Insecure {
			t.Errorf("%#04x: not Insecure CipherSuite returned by InsecureCipherSuites()", c.ID)
		}
	}

	CipherSuiteByID := func(id uint16) *CipherSuite {
		for _, c := range CipherSuites() {
			if c.ID == id {
				return c
			}
		}
		for _, c := range InsecureCipherSuites() {
			if c.ID == id {
				return c
			}
		}
		return nil
	}

	for _, c := range cipherSuites {
		cc := CipherSuiteByID(c.id)
		if cc == nil {
			t.Errorf("%#04x: no CipherSuite entry", c.id)
			continue
		}

		if tls12Only := c.flags&suiteTLS12 != 0; tls12Only && len(cc.SupportedVersions) != 1 {
			t.Errorf("%#04x: suite is TLS 1.2 only, but SupportedVersions is %v", c.id, cc.SupportedVersions)
		} else if !tls12Only && len(cc.SupportedVersions) != 3 {
			t.Errorf("%#04x: suite TLS 1.0-1.2, but SupportedVersions is %v", c.id, cc.SupportedVersions)
		}

		if cc.Insecure {
			if slices.Contains(defaultCipherSuites(false), c.id) {
				t.Errorf("%#04x: insecure suite in default list", c.id)
			}
		} else {
			if !slices.Contains(defaultCipherSuites(false), c.id) {
				t.Errorf("%#04x: secure suite not in default list", c.id)
			}
		}

		if got := CipherSuiteName(c.id); got != cc.Name {
			t.Errorf("%#04x: unexpected CipherSuiteName: got %q, expected %q", c.id, got, cc.Name)
		}
	}
	for _, c := range cipherSuitesTLS13 {
		cc := CipherSuiteByID(c.id)
		if cc == nil {
			t.Errorf("%#04x: no CipherSuite entry", c.id)
			continue
		}

		if cc.Insecure {
			t.Errorf("%#04x: Insecure %v, expected false", c.id, cc.Insecure)
		}
		if len(cc.SupportedVersions) != 1 || cc.SupportedVersions[0] != VersionTLS13 {
			t.Errorf("%#04x: suite is TLS 1.3 only, but SupportedVersions is %v", c.id, cc.SupportedVersions)
		}

		if got := CipherSuiteName(c.id); got != cc.Name {
			t.Errorf("%#04x: unexpected CipherSuiteName: got %q, expected %q", c.id, got, cc.Name)
		}
	}

	if got := CipherSuiteName(0xabc); got != "0x0ABC" {
		t.Errorf("unexpected fallback CipherSuiteName: got %q, expected 0x0ABC", got)
	}

	if len(cipherSuitesPreferenceOrder) != len(cipherSuites) {
		t.Errorf("cipherSuitesPreferenceOrder is not the same size as cipherSuites")
	}
	if len(cipherSuitesPreferenceOrderNoAES) != len(cipherSuitesPreferenceOrder) {
		t.Errorf("cipherSuitesPreferenceOrderNoAES is not the same size as cipherSuitesPreferenceOrder")
	}

	// Check that disabled suites are marked insecure.
	for id := range disabledCipherSuites {
		c := CipherSuiteByID(id)
		if c == nil {
			t.Errorf("%#04x: no CipherSuite entry", id)
			continue
		}
		if !c.Insecure {
			t.Errorf("%#04x: disabled by default but not marked insecure", id)
		}
	}

	for i, prefOrder := range [][]uint16{cipherSuitesPreferenceOrder, cipherSuitesPreferenceOrderNoAES} {
		// Check that insecure and HTTP/2 bad cipher suites are at the end of
		// the preference lists.
		var sawInsecure, sawBad bool
		for _, id := range prefOrder {
			c := CipherSuiteByID(id)
			if c == nil {
				t.Errorf("%#04x: no CipherSuite entry", id)
				continue
			}

			if c.Insecure {
				sawInsecure = true
			} else if sawInsecure {
				t.Errorf("%#04x: secure suite after insecure one(s)", id)
			}

			if http2isBadCipher(id) {
				sawBad = true
			} else if sawBad {
				t.Errorf("%#04x: non-bad suite after bad HTTP/2 one(s)", id)
			}
		}

		// Check that the list is sorted according to the documented criteria.
		isBetter := func(a, b uint16) int {
			aSuite, bSuite := cipherSuiteByID(a), cipherSuiteByID(b)
			aName, bName := CipherSuiteName(a), CipherSuiteName(b)
			// * < RC4
			if !strings.Contains(aName, "RC4") && strings.Contains(bName, "RC4") {
				return -1
			} else if strings.Contains(aName, "RC4") && !strings.Contains(bName, "RC4") {
				return +1
			}
			// * < CBC_SHA256
			if !strings.Contains(aName, "CBC_SHA256") && strings.Contains(bName, "CBC_SHA256") {
				return -1
			} else if strings.Contains(aName, "CBC_SHA256") && !strings.Contains(bName, "CBC_SHA256") {
				return +1
			}
			// * < 3DES
			if !strings.Contains(aName, "3DES") && strings.Contains(bName, "3DES") {
				return -1
			} else if strings.Contains(aName, "3DES") && !strings.Contains(bName, "3DES") {
				return +1
			}
			// ECDHE < *
			if aSuite.flags&suiteECDHE != 0 && bSuite.flags&suiteECDHE == 0 {
				return -1
			} else if aSuite.flags&suiteECDHE == 0 && bSuite.flags&suiteECDHE != 0 {
				return +1
			}
			// AEAD < CBC
			if aSuite.aead != nil && bSuite.aead == nil {
				return -1
			} else if aSuite.aead == nil && bSuite.aead != nil {
				return +1
			}
			// AES < ChaCha20
			if strings.Contains(aName, "AES") && strings.Contains(bName, "CHACHA20") {
				// negative for cipherSuitesPreferenceOrder
				if i == 0 {
					return -1
				} else {
					return +1
				}
			} else if strings.Contains(aName, "CHACHA20") && strings.Contains(bName, "AES") {
				// negative for cipherSuitesPreferenceOrderNoAES
				if i != 0 {
					return -1
				} else {
					return +1
				}
			}
			// AES-128 < AES-256
			if strings.Contains(aName, "AES_128") && strings.Contains(bName, "AES_256") {
				return -1
			} else if strings.Contains(aName, "AES_256") && strings.Contains(bName, "AES_128") {
				return +1
			}
			// ECDSA < RSA
			if aSuite.flags&suiteECSign != 0 && bSuite.flags&suiteECSign == 0 {
				return -1
			} else if aSuite.flags&suiteECSign == 0 && bSuite.flags&suiteECSign != 0 {
				return +1
			}
			t.Fatalf("two ciphersuites are equal by all criteria: %v and %v", aName, bName)
			panic("unreachable")
		}
		if !slices.IsSortedFunc(prefOrder, isBetter) {
			t.Error("preference order is not sorted according to the rules")
		}
	}
}

func TestVersionName(t *testing.T) {
	if got, exp := VersionName(VersionTLS13), "TLS 1.3"; got != exp {
		t.Errorf("unexpected VersionName: got %q, expected %q", got, exp)
	}
	if got, exp := VersionName(0x12a), "0x012A"; got != exp {
		t.Errorf("unexpected fallback VersionName: got %q, expected %q", got, exp)
	}
}

// http2isBadCipher is copied from net/http.
// TODO: if it ends up exposed somewhere, use that instead.
func http2isBadCipher(cipher uint16) bool {
	switch cipher {
	case TLS_RSA_WITH_RC4_128_SHA,
		TLS_RSA_WITH_3DES_EDE_CBC_SHA,
		TLS_RSA_WITH_AES_128_CBC_SHA,
		TLS_RSA_WITH_AES_256_CBC_SHA,
		TLS_RSA_WITH_AES_128_CBC_SHA256,
		TLS_RSA_WITH_AES_128_GCM_SHA256,
		TLS_RSA_WITH_AES_256_GCM_SHA384,
		TLS_ECDHE_ECDSA_WITH_RC4_128_SHA,
		TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,
		TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,
		TLS_ECDHE_RSA_WITH_RC4_128_SHA,
		TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA,
		TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,
		TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,
		TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,
		TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256:
		return true
	default:
		return false
	}
}

type brokenSigner struct{ crypto.Signer }

func (s brokenSigner) Sign(rand io.Reader, digest []byte, opts crypto.SignerOpts) (signature []byte, err error) {
	// Replace opts with opts.HashFunc(), so rsa.PSSOptions are discarded.
	return s.Signer.Sign(rand, digest, opts.HashFunc())
}

// TestPKCS1OnlyCert uses a client certificate with a broken crypto.Signer that
// always makes PKCS #1 v1.5 signatures, so can't be used with RSA-PSS.
func TestPKCS1OnlyCert(t *testing.T) {
	clientConfig := testConfigClient.Clone()
	clientConfig.Certificates = []Certificate{{
		Certificate: testClientRSA2048Cert.Certificate,
		PrivateKey:  brokenSigner{testClientRSA2048Key},
	}}
	serverConfig := testConfigServer.Clone()
	serverConfig.MaxVersion = VersionTLS12 // TLS 1.3 doesn't support PKCS #1 v1.5
	serverConfig.ClientAuth = RequireAnyClientCert

	// If RSA-PSS is selected, the handshake should fail.
	if _, _, err := testHandshake(t, clientConfig, serverConfig); err == nil {
		t.Fatal("expected broken certificate to cause connection to fail")
	}

	clientConfig.Certificates[0].SupportedSignatureAlgorithms =
		[]SignatureScheme{PKCS1WithSHA1, PKCS1WithSHA256}

	// But if the certificate restricts supported algorithms, RSA-PSS should not
	// be selected, and the handshake should succeed.
	if _, _, err := testHandshake(t, clientConfig, serverConfig); err != nil {
		t.Error(err)
	}
}

func TestVerifyCertificates(t *testing.T) {
	// See https://go.dev/issue/31641.
	t.Run("TLSv12", func(t *testing.T) { testVerifyCertificates(t, VersionTLS12) })
	t.Run("TLSv13", func(t *testing.T) { testVerifyCertificates(t, VersionTLS13) })
}

func testVerifyCertificates(t *testing.T, version uint16) {
	tests := []struct {
		name string

		InsecureSkipVerify bool
		ClientAuth         ClientAuthType
		ClientCertificates bool
	}{
		{
			name: "defaults",
		},
		{
			name:               "InsecureSkipVerify",
			InsecureSkipVerify: true,
		},
		{
			name:       "RequestClientCert with no certs",
			ClientAuth: RequestClientCert,
		},
		{
			name:               "RequestClientCert with certs",
			ClientAuth:         RequestClientCert,
			ClientCertificates: true,
		},
		{
			name:               "RequireAnyClientCert",
			ClientAuth:         RequireAnyClientCert,
			ClientCertificates: true,
		},
		{
			name:       "VerifyClientCertIfGiven with no certs",
			ClientAuth: VerifyClientCertIfGiven,
		},
		{
			name:               "VerifyClientCertIfGiven with certs",
			ClientAuth:         VerifyClientCertIfGiven,
			ClientCertificates: true,
		},
		{
			name:               "RequireAndVerifyClientCert",
			ClientAuth:         RequireAndVerifyClientCert,
			ClientCertificates: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			var serverVerifyConnection, clientVerifyConnection bool
			var serverVerifyPeerCertificates, clientVerifyPeerCertificates bool

			clientConfig := testConfigClient.Clone()
			clientConfig.MaxVersion = version
			clientConfig.MinVersion = version
			clientConfig.ClientSessionCache = NewLRUClientSessionCache(1)
			serverConfig := testConfigServer.Clone()
			serverConfig.MaxVersion = version
			serverConfig.MinVersion = version

			clientConfig.VerifyConnection = func(cs ConnectionState) error {
				clientVerifyConnection = true
				return nil
			}
			clientConfig.VerifyPeerCertificate = func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
				clientVerifyPeerCertificates = true
				return nil
			}
			serverConfig.VerifyConnection = func(cs ConnectionState) error {
				serverVerifyConnection = true
				return nil
			}
			serverConfig.VerifyPeerCertificate = func(rawCerts [][]byte, verifiedChains [][]*x509.Certificate) error {
				serverVerifyPeerCertificates = true
				return nil
			}

			clientConfig.InsecureSkipVerify = test.InsecureSkipVerify
			serverConfig.ClientAuth = test.ClientAuth
			if !test.ClientCertificates {
				clientConfig.Certificates = nil
			}

			if _, _, err := testHandshake(t, clientConfig, serverConfig); err != nil {
				t.Fatal(err)
			}

			want := serverConfig.ClientAuth != NoClientCert
			if serverVerifyPeerCertificates != want {
				t.Errorf("VerifyPeerCertificates on the server: got %v, want %v",
					serverVerifyPeerCertificates, want)
			}
			if !clientVerifyPeerCertificates {
				t.Errorf("VerifyPeerCertificates not called on the client")
			}
			if !serverVerifyConnection {
				t.Error("VerifyConnection did not get called on the server")
			}
			if !clientVerifyConnection {
				t.Error("VerifyConnection did not get called on the client")
			}

			serverVerifyPeerCertificates, clientVerifyPeerCertificates = false, false
			serverVerifyConnection, clientVerifyConnection = false, false
			cs, _, err := testHandshake(t, clientConfig, serverConfig)
			if err != nil {
				t.Fatal(err)
			}
			if !cs.DidResume {
				t.Error("expected resumption")
			}

			if serverVerifyPeerCertificates {
				t.Error("VerifyPeerCertificates got called on the server on resumption")
			}
			if clientVerifyPeerCertificates {
				t.Error("VerifyPeerCertificates got called on the client on resumption")
			}
			if !serverVerifyConnection {
				t.Error("VerifyConnection did not get called on the server on resumption")
			}
			if !clientVerifyConnection {
				t.Error("VerifyConnection did not get called on the client on resumption")
			}
		})
	}
}

func TestHandshakeMLKEM(t *testing.T) {
	if boring.Enabled && fips140tls.Required() {
		t.Skip("ML-KEM not supported in BoringCrypto FIPS mode")
	}
	defaultWithPQ := []CurveID{X25519MLKEM768, SecP256r1MLKEM768, SecP384r1MLKEM1024,
		X25519, CurveP256, CurveP384, CurveP521}
	defaultWithoutPQ := []CurveID{X25519, CurveP256, CurveP384, CurveP521}
	var tests = []struct {
		name           string
		clientConfig   func(*Config)
		serverConfig   func(*Config)
		preparation    func(*testing.T)
		expectClient   []CurveID
		expectSelected CurveID
		expectHRR      bool
	}{
		{
			name:           "Default",
			expectClient:   defaultWithPQ,
			expectSelected: X25519MLKEM768,
		},
		{
			name: "ClientCurvePreferences",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{X25519}
			},
			expectClient:   []CurveID{X25519},
			expectSelected: X25519,
		},
		{
			name: "ServerCurvePreferencesX25519",
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{X25519}
			},
			expectClient:   defaultWithPQ,
			expectSelected: X25519,
		},
		{
			name: "ServerCurvePreferencesHRR",
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP256}
			},
			expectClient:   defaultWithPQ,
			expectSelected: CurveP256,
			expectHRR:      true,
		},
		{
			name: "SecP256r1MLKEM768-Only",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{SecP256r1MLKEM768}
			},
			expectClient:   []CurveID{SecP256r1MLKEM768},
			expectSelected: SecP256r1MLKEM768,
		},
		{
			name: "SecP256r1MLKEM768-HRR",
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{SecP256r1MLKEM768, CurveP256}
			},
			expectClient:   defaultWithPQ,
			expectSelected: SecP256r1MLKEM768,
			expectHRR:      true,
		},
		{
			name: "SecP384r1MLKEM1024",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{SecP384r1MLKEM1024, CurveP384}
			},
			expectClient:   []CurveID{SecP384r1MLKEM1024, CurveP384},
			expectSelected: SecP384r1MLKEM1024,
		},
		{
			name: "CurveP256NoHRR",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{SecP256r1MLKEM768, CurveP256}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP256}
			},
			expectClient:   []CurveID{SecP256r1MLKEM768, CurveP256},
			expectSelected: CurveP256,
		},
		{
			name: "CurveP384HRR",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{SecP256r1MLKEM768, CurveP384}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP384}
			},
			expectClient:   []CurveID{SecP256r1MLKEM768, CurveP384},
			expectSelected: CurveP384,
			expectHRR:      true,
		},
		{
			name: "ClientMLKEMOnly",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{X25519MLKEM768}
			},
			expectClient:   []CurveID{X25519MLKEM768},
			expectSelected: X25519MLKEM768,
		},
		{
			name: "ClientSortedCurvePreferences",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP256, X25519MLKEM768}
			},
			expectClient:   []CurveID{X25519MLKEM768, CurveP256},
			expectSelected: X25519MLKEM768,
		},
		{
			name: "ClientTLSv12",
			clientConfig: func(config *Config) {
				config.MaxVersion = VersionTLS12
			},
			expectClient:   defaultWithoutPQ,
			expectSelected: X25519,
		},
		{
			name: "ServerTLSv12",
			serverConfig: func(config *Config) {
				config.MaxVersion = VersionTLS12
			},
			expectClient:   defaultWithPQ,
			expectSelected: X25519,
		},
		// [uTLS] TLS GODEBUG default overrides are unsupported.
		{
			name: "ExplicitCurvePreferences",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP256, SecP256r1MLKEM768, MLKEM1024}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{CurveP256, SecP256r1MLKEM768, MLKEM1024}
			},
			expectClient:   []CurveID{SecP256r1MLKEM768, MLKEM1024, CurveP256},
			expectSelected: SecP256r1MLKEM768,
		},
		{
			name: "ClientMLKEM1024Only",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{MLKEM1024}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = append(defaultWithPQ, MLKEM1024)
			},
			expectClient:   []CurveID{MLKEM1024},
			expectSelected: MLKEM1024,
		},
		{
			name: "ServerMLKEM1024Only",
			clientConfig: func(config *Config) {
				config.CurvePreferences = append(defaultWithPQ, MLKEM1024)
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{MLKEM1024}
			},
			expectClient: []CurveID{X25519MLKEM768, SecP256r1MLKEM768, SecP384r1MLKEM1024,
				MLKEM1024, X25519, CurveP256, CurveP384, CurveP521},
			expectSelected: MLKEM1024,
			expectHRR:      true,
		},
		{
			name: "MLKEM1024NotPreferredOverHybrid",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{MLKEM1024, X25519MLKEM768}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{MLKEM1024, X25519MLKEM768}
			},
			expectClient:   []CurveID{X25519MLKEM768, MLKEM1024},
			expectSelected: X25519MLKEM768,
		},
		{
			name: "MLKEM1024PreferredOverECC",
			clientConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{X25519, MLKEM1024}
			},
			serverConfig: func(config *Config) {
				config.CurvePreferences = []CurveID{X25519, MLKEM1024}
			},
			expectClient:   []CurveID{MLKEM1024, X25519},
			expectSelected: MLKEM1024,
		},
	}

	baseServerConfig := testConfigServer.Clone()
	baseClientConfig := testConfigClient.Clone()
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if fips140tls.Required() && test.expectSelected == X25519 {
				t.Skip("X25519 not supported in FIPS mode")
			}
			if test.preparation != nil {
				test.preparation(t)
			} else {
				t.Parallel()
			}
			serverConfig := baseServerConfig.Clone()
			if test.serverConfig != nil {
				test.serverConfig(serverConfig)
			}
			serverConfig.GetConfigForClient = func(hello *ClientHelloInfo) (*Config, error) {
				expectClient := slices.Clone(test.expectClient)
				expectClient = slices.DeleteFunc(expectClient, func(c CurveID) bool {
					return fips140tls.Required() && c == X25519
				})
				if !slices.Equal(hello.SupportedCurves, expectClient) {
					t.Errorf("got client curves %v, expected %v", hello.SupportedCurves, expectClient)
				}
				return nil, nil
			}
			clientConfig := baseClientConfig.Clone()
			if test.clientConfig != nil {
				test.clientConfig(clientConfig)
			}
			ss, cs, err := testHandshake(t, clientConfig, serverConfig)
			if err != nil {
				t.Fatal(err)
			}
			if ss.CurveID != test.expectSelected {
				t.Errorf("server selected curve %v, expected %v", ss.CurveID, test.expectSelected)
			}
			if cs.CurveID != test.expectSelected {
				t.Errorf("client selected curve %v, expected %v", cs.CurveID, test.expectSelected)
			}
			if test.expectHRR {
				if !ss.HelloRetryRequest {
					t.Error("server did not use HRR")
				}
				if !cs.HelloRetryRequest {
					t.Error("client did not use HRR")
				}
			} else {
				if ss.HelloRetryRequest {
					t.Error("server used HRR")
				}
				if cs.HelloRetryRequest {
					t.Error("client used HRR")
				}
			}
		})
	}
}

// TestSupportedSignatureAlgorithmsMLDSAGating asserts the spec-mandated
// version-level gating of ML-DSA. Outside the FIPS 140-3 v1.0.0 module:
// ML-DSA MUST NOT appear in the TLS 1.2 advertised list, MUST appear in
// the TLS 1.3 advertised list. Under FIPS 140-3 v1.0.0 (which doesn't include
// ML-DSA), ML-DSA MUST NOT be advertised in either extension.
func TestSupportedSignatureAlgorithmsMLDSAGating(t *testing.T) {
	mldsaSchemes := []SignatureScheme{MLDSA44, MLDSA65, MLDSA87}

	if fips140.Version() == "v1.0.0" {
		fullRange := supportedSignatureAlgorithms(VersionTLS10, VersionTLS13)
		certExt := supportedSignatureAlgorithmsCert(VersionTLS10, VersionTLS13)
		for _, s := range mldsaSchemes {
			if slices.Contains(fullRange, s) {
				t.Errorf("supportedSignatureAlgorithms contains %v under FIPS 140-3 v1.0.0", s)
			}
			if slices.Contains(certExt, s) {
				t.Errorf("supportedSignatureAlgorithmsCert contains %v under FIPS 140-3 v1.0.0", s)
			}
		}
		return
	}

	tls12Only := supportedSignatureAlgorithms(VersionTLS12, VersionTLS12)
	tls12OnlyCert := supportedSignatureAlgorithmsCert(VersionTLS12, VersionTLS12)
	for _, s := range mldsaSchemes {
		if slices.Contains(tls12Only, s) {
			t.Errorf("supportedSignatureAlgorithms(TLS12, TLS12) contains %v; ML-DSA must not be advertised in TLS 1.2", s)
		}
		if slices.Contains(tls12OnlyCert, s) {
			t.Errorf("supportedSignatureAlgorithmsCert(TLS12, TLS12) contains %v; ML-DSA must not be advertised in TLS 1.2", s)
		}
	}
	tls13Only := supportedSignatureAlgorithms(VersionTLS13, VersionTLS13)
	tls13OnlyCert := supportedSignatureAlgorithmsCert(VersionTLS13, VersionTLS13)
	for _, s := range mldsaSchemes {
		if !slices.Contains(tls13Only, s) {
			t.Errorf("supportedSignatureAlgorithms(TLS13, TLS13) is missing %v", s)
		}
		if !slices.Contains(tls13OnlyCert, s) {
			t.Errorf("supportedSignatureAlgorithmsCert(TLS13, TLS13) is missing %v", s)
		}
	}
}

func TestHandshakeMLDSA(t *testing.T) {
	for _, tt := range []struct {
		name   string
		cert   Certificate
		client Certificate
	}{
		{"MLDSA44", testMLDSA44Cert, testClientMLDSA44Cert},
		{"MLDSA65", testMLDSA65Cert, testClientMLDSA65Cert},
		{"MLDSA87", testMLDSA87Cert, testClientMLDSA87Cert},
	} {
		t.Run(tt.name+"/ServerAuth", func(t *testing.T) {
			t.Parallel()
			serverConfig := testConfigServer.Clone()
			serverConfig.Certificates = []Certificate{tt.cert}
			clientConfig := testConfigClient.Clone()
			_, cs, err := testHandshake(t, clientConfig, serverConfig)
			if fips140.Version() == "v1.0.0" {
				if err == nil {
					t.Errorf("ML-DSA handshake unexpectedly succeeded with FIPS 140-3 module v1.0.0")
				}
				// Loaded certificate has cert bytes but no usable private key.
				if len(tt.cert.Certificate) == 0 {
					t.Errorf("certificate bytes missing")
				}
				if tt.cert.PrivateKey != nil {
					t.Errorf("PrivateKey = %T, want nil under v1.0.0", tt.cert.PrivateKey)
				}
				return
			}
			if err != nil {
				t.Fatalf("handshake: %v", err)
			}
			if _, ok := cs.PeerCertificates[0].PublicKey.(*mldsa.PublicKey); !ok {
				t.Errorf("server peer cert public key = %T, want *mldsa.PublicKey",
					cs.PeerCertificates[0].PublicKey)
			}
		})
		t.Run(tt.name+"/ClientAuth", func(t *testing.T) {
			t.Parallel()
			serverConfig := testConfigServer.Clone()
			serverConfig.Certificates = []Certificate{testECDSAP256Cert}
			serverConfig.ClientAuth = RequireAndVerifyClientCert
			clientConfig := testConfigClient.Clone()
			clientConfig.Certificates = []Certificate{tt.client}
			ss, _, err := testHandshake(t, clientConfig, serverConfig)
			if fips140.Version() == "v1.0.0" {
				if err == nil {
					t.Errorf("ML-DSA handshake unexpectedly succeeded with FIPS 140-3 module v1.0.0")
				}
				// Loaded certificate has cert bytes but no usable private key.
				if len(tt.client.Certificate) == 0 {
					t.Errorf("certificate bytes missing")
				}
				if tt.client.PrivateKey != nil {
					t.Errorf("PrivateKey = %T, want nil under v1.0.0", tt.client.PrivateKey)
				}
				return
			}
			if err != nil {
				t.Fatalf("handshake: %v", err)
			}
			if _, ok := ss.PeerCertificates[0].PublicKey.(*mldsa.PublicKey); !ok {
				t.Errorf("client peer cert public key = %T, want *mldsa.PublicKey",
					ss.PeerCertificates[0].PublicKey)
			}
		})
		t.Run(tt.name+"/MutualAuth", func(t *testing.T) {
			t.Parallel()
			serverConfig := testConfigServer.Clone()
			serverConfig.Certificates = []Certificate{tt.cert}
			serverConfig.ClientAuth = RequireAndVerifyClientCert
			clientConfig := testConfigClient.Clone()
			clientConfig.Certificates = []Certificate{tt.client}
			ss, cs, err := testHandshake(t, clientConfig, serverConfig)
			if fips140.Version() == "v1.0.0" {
				if err == nil {
					t.Errorf("ML-DSA handshake unexpectedly succeeded with FIPS 140-3 module v1.0.0")
				}
				return
			}
			if err != nil {
				t.Fatalf("handshake: %v", err)
			}
			if _, ok := cs.PeerCertificates[0].PublicKey.(*mldsa.PublicKey); !ok {
				t.Errorf("client-side peer cert public key = %T, want *mldsa.PublicKey",
					cs.PeerCertificates[0].PublicKey)
			}
			if _, ok := ss.PeerCertificates[0].PublicKey.(*mldsa.PublicKey); !ok {
				t.Errorf("server-side peer cert public key = %T, want *mldsa.PublicKey",
					ss.PeerCertificates[0].PublicKey)
			}
		})
		for _, v := range []uint16{VersionTLS10, VersionTLS12} {
			name := tt.name + "/RejectedVersion/" + VersionName(v)
			t.Run(name+"/Server", func(t *testing.T) {
				if v == VersionTLS10 {
					skipFIPS(t) // TLS 1.0 is not allowed in FIPS 140-3 mode.
				}
				cryptotest.MustMinimumFIPS140ModuleVersion(t, "v1.26.0")
				t.Parallel()
				serverConfig := testConfigServer.Clone()
				serverConfig.MinVersion = VersionTLS10
				serverConfig.Certificates = []Certificate{tt.cert}
				serverConfig.MaxVersion = v
				clientConfig := testConfigClient.Clone()
				clientConfig.MinVersion = VersionTLS10
				if _, _, err := testHandshake(t, clientConfig, serverConfig); err == nil {
					t.Fatal("expected handshake failure when ML-DSA is the only server cert and the negotiation is not TLS 1.3")
				} else if !strings.Contains(err.Error(), "ML-DSA") {
					t.Errorf("error message should mention ML-DSA, got %q", err)
				}

				serverConfig.MaxVersion = 0
				clientConfig.MaxVersion = v
				if _, _, err := testHandshake(t, clientConfig, serverConfig); err == nil {
					t.Fatal("expected handshake failure when ML-DSA is the only server cert and the negotiation is not TLS 1.3")
				} else if !strings.Contains(err.Error(), "ML-DSA") {
					t.Errorf("error message should mention ML-DSA, got %q", err)
				}
			})
			t.Run(name+"/Client", func(t *testing.T) {
				cryptotest.MustMinimumFIPS140ModuleVersion(t, "v1.26.0")
				t.Parallel()
				serverConfig := testConfigServer.Clone()
				serverConfig.MinVersion = VersionTLS10
				serverConfig.ClientAuth = RequireAndVerifyClientCert
				clientConfig := testConfigClient.Clone()
				clientConfig.MinVersion = VersionTLS10
				clientConfig.Certificates = []Certificate{tt.client}
				clientConfig.MaxVersion = v
				if _, _, err := testHandshake(t, clientConfig, serverConfig); err == nil {
					t.Fatal("expected handshake failure when ML-DSA is the only client cert and the negotiation is not TLS 1.3")
				}
				// The error message on the client can't be helpful because we
				// don't know if the server requires a certificate until/unless
				// the server aborts later in the handshake, by which time we
				// lost track of which certificate we didn't offer and why.

				clientConfig.MaxVersion = 0
				serverConfig.MaxVersion = v
				if _, _, err := testHandshake(t, clientConfig, serverConfig); err == nil {
					t.Fatal("expected handshake failure when ML-DSA is the only client cert and the negotiation is not TLS 1.3")
				}
			})
		}
		t.Run(tt.name+"/CorruptedSignature/Server", func(t *testing.T) {
			cryptotest.MustMinimumFIPS140ModuleVersion(t, "v1.26.0")
			t.Parallel()
			serverConfig := testConfigServer.Clone()
			serverConfig.Certificates = []Certificate{{
				Certificate: tt.cert.Certificate,
				PrivateKey:  bitFlippingSigner{tt.cert.PrivateKey.(crypto.Signer)},
			}}
			clientConfig := testConfigClient.Clone()
			_, _, err := testHandshake(t, clientConfig, serverConfig)
			if err == nil {
				t.Fatal("handshake unexpectedly succeeded with corrupted ML-DSA signature")
			}
			// The client returns the verification error; the server returns
			// "remote error: tls: decrypt_error" reflecting the alert.
			if !strings.Contains(err.Error(), "decrypt") &&
				!strings.Contains(err.Error(), "ML-DSA verification failure") {
				t.Errorf("error = %q; want one mentioning decrypt_error or ML-DSA verification", err)
			}
		})
		t.Run(tt.name+"/CorruptedSignature/Client", func(t *testing.T) {
			cryptotest.MustMinimumFIPS140ModuleVersion(t, "v1.26.0")
			t.Parallel()
			serverConfig := testConfigServer.Clone()
			serverConfig.ClientAuth = RequireAndVerifyClientCert
			clientConfig := testConfigClient.Clone()
			clientConfig.Certificates = []Certificate{{
				Certificate: tt.client.Certificate,
				PrivateKey:  bitFlippingSigner{tt.client.PrivateKey.(crypto.Signer)},
			}}
			_, _, err := testHandshake(t, clientConfig, serverConfig)
			if err == nil {
				t.Fatal("handshake unexpectedly succeeded with corrupted ML-DSA signature")
			}
			// The server returns the verification error; the client returns
			// "remote error: tls: decrypt_error" reflecting the alert.
			if !strings.Contains(err.Error(), "decrypt") &&
				!strings.Contains(err.Error(), "ML-DSA verification failure") {
				t.Errorf("error = %q; want one mentioning decrypt_error or ML-DSA verification", err)
			}
		})
	}
}

func TestX509KeyPairPopulateCertificate(t *testing.T) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	keyDER, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		t.Fatal(err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER})
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "test"},
	}
	certDER, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, key.Public(), key)
	if err != nil {
		t.Fatal(err)
	}
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	cert, err := X509KeyPair(certPEM, keyPEM)
	if err != nil {
		t.Fatal(err)
	}
	if cert.Leaf == nil {
		t.Fatal("Leaf should be populated")
	}
}

func TestEarlyLargeCertMsg(t *testing.T) {
	client, server := localPipe(t)

	go func() {
		if _, err := client.Write([]byte{byte(recordTypeHandshake), 3, 4, 0, 4, typeCertificate, 1, 255, 255}); err != nil {
			t.Log(err)
		}
	}()

	expectedErr := "tls: handshake message of length 131071 bytes exceeds maximum of 65536 bytes"
	servConn := Server(server, testConfigServer.Clone())
	err := servConn.Handshake()
	if err == nil {
		t.Fatal("unexpected success")
	}
	if err.Error() != expectedErr {
		t.Fatalf("unexpected error: got %q, want %q", err, expectedErr)
	}
}

func TestLargeCertMsg(t *testing.T) {
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "test"},
		ExtraExtensions: []pkix.Extension{
			{
				Id: asn1.ObjectIdentifier{1, 2, 3},
				// Ballast to inflate the certificate beyond the
				// regular handshake record size.
				Value: make([]byte, 65536),
			},
		},
	}
	cert, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, k.Public(), k)
	if err != nil {
		t.Fatal(err)
	}

	clientConfig, serverConfig := testConfigClient.Clone(), testConfigServer.Clone()
	clientConfig.InsecureSkipVerify = true
	serverConfig.Certificates = []Certificate{
		{
			Certificate: [][]byte{cert},
			PrivateKey:  k,
		},
	}
	if _, _, err := testHandshake(t, clientConfig, serverConfig); err != nil {
		t.Fatalf("unexpected failure: %s", err)
	}
}

func TestECH(t *testing.T) {
	testECHSpec(t, nil, true)
}

// [uTLS] Exercise ECH with custom ClientHello specs as well as the Go path.
func testECHSpec(t *testing.T, spec *ClientHelloSpec, expectSuccess bool) {
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		DNSNames:     []string{"public.example"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(time.Hour),
	}
	publicCertDER, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, k.Public(), k)
	if err != nil {
		t.Fatal(err)
	}
	publicCert, err := x509.ParseCertificate(publicCertDER)
	if err != nil {
		t.Fatal(err)
	}
	tmpl.DNSNames[0] = "secret.example"
	secretCertDER, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, k.Public(), k)
	if err != nil {
		t.Fatal(err)
	}
	secretCert, err := x509.ParseCertificate(secretCertDER)
	if err != nil {
		t.Fatal(err)
	}

	marshalECHConfig := func(version uint16, id uint8, pubKey []byte, publicName string, maxNameLen uint8) []byte {
		builder := cryptobyte.NewBuilder(nil)
		builder.AddUint16(version)
		builder.AddUint16LengthPrefixed(func(builder *cryptobyte.Builder) {
			builder.AddUint8(id)
			builder.AddUint16(0x0020 /* DHKEM(X25519, HKDF-SHA256) */)
			builder.AddUint16LengthPrefixed(func(builder *cryptobyte.Builder) {
				builder.AddBytes(pubKey)
			})
			builder.AddUint16LengthPrefixed(func(builder *cryptobyte.Builder) {
				builder.AddUint16(0x0001 /* HKDF-SHA256 */)
				builder.AddUint16(0x0001 /* AES-128-GCM */)
			})
			builder.AddUint8(maxNameLen)
			builder.AddUint8LengthPrefixed(func(builder *cryptobyte.Builder) {
				builder.AddBytes([]byte(publicName))
			})
			builder.AddUint16(0) // extensions
		})

		return builder.BytesOrPanic()
	}

	echKey, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	echConfig := marshalECHConfig(extensionEncryptedClientHello, 123, echKey.PublicKey().Bytes(), "public.example", 32)

	builder := cryptobyte.NewBuilder(nil)
	builder.AddUint16LengthPrefixed(func(builder *cryptobyte.Builder) {
		builder.AddBytes(echConfig)
	})
	echConfigList := builder.BytesOrPanic()

	clientConfig, serverConfig := testConfigClient.Clone(), testConfigServer.Clone()
	clientConfig.Time = nil
	clientConfig.MinVersion = VersionTLS13
	clientConfig.ServerName = "secret.example"
	clientConfig.RootCAs = x509.NewCertPool()
	clientConfig.RootCAs.AddCert(secretCert)
	clientConfig.RootCAs.AddCert(publicCert)
	clientConfig.EncryptedClientHelloConfigList = echConfigList
	clientConfig.ClientSessionCache = NewLRUClientSessionCache(2)
	serverConfig.InsecureSkipVerify = false
	serverConfig.Time = nil
	serverConfig.MinVersion = VersionTLS13
	serverConfig.ServerName = "public.example"
	serverConfig.Certificates = []Certificate{
		{Certificate: [][]byte{publicCertDER}, PrivateKey: k},
		{Certificate: [][]byte{secretCertDER}, PrivateKey: k},
	}
	serverConfig.EncryptedClientHelloKeys = []EncryptedClientHelloKey{
		{Config: echConfig, PrivateKey: echKey.Bytes(), SendAsRetry: true},
	}

	check := func() {
		ss, cs, err := testUtlsHandshake(t, clientConfig, serverConfig, spec)
		if !expectSuccess {
			if err == nil {
				t.Fatal("unexpected handshake success, expected failure")
			}
			return
		}
		if err != nil {
			t.Fatalf("unexpected failure: %s", err)
		}
		if !ss.ECHAccepted {
			t.Fatal("server ConnectionState shows ECH not accepted")
		}
		if !cs.ECHAccepted {
			t.Fatal("client ConnectionState shows ECH not accepted")
		}
		if cs.ServerName != "secret.example" || ss.ServerName != "secret.example" {
			t.Fatalf("unexpected ConnectionState.ServerName, want %q, got server:%q, client: %q", "secret.example", ss.ServerName, cs.ServerName)
		}
		if len(cs.VerifiedChains) != 1 {
			t.Fatal("unexpected number of certificate chains")
		}
		if len(cs.VerifiedChains[0]) != 1 {
			t.Fatal("unexpected number of certificates")
		}
		if !cs.VerifiedChains[0][0].Equal(secretCert) {
			t.Fatal("unexpected certificate")
		}
	}

	check()

	serverConfig.GetEncryptedClientHelloKeys = func(_ *ClientHelloInfo) ([]EncryptedClientHelloKey, error) {
		return []EncryptedClientHelloKey{{Config: echConfig, PrivateKey: echKey.Bytes(), SendAsRetry: true}}, nil
	}
	randKey, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	randConfig := marshalECHConfig(extensionEncryptedClientHello, 32, randKey.PublicKey().Bytes(), "random.example", 32)
	serverConfig.EncryptedClientHelloKeys = []EncryptedClientHelloKey{
		{Config: randConfig, PrivateKey: randKey.Bytes(), SendAsRetry: true},
	}

	check()

	// A server configured with an unsupported-version ECHConfig ahead of a
	// usable one must skip the unusable entry (per RFC 9849 §4) and
	// trial-decrypt against the next key, rather than aborting the handshake
	// on the first entry.
	unsupportedKey, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	unsupportedConfig := marshalECHConfig(0xbadd, 99, unsupportedKey.PublicKey().Bytes(), "public.example", 32)
	serverConfig.GetEncryptedClientHelloKeys = nil
	serverConfig.EncryptedClientHelloKeys = []EncryptedClientHelloKey{
		{Config: unsupportedConfig, PrivateKey: unsupportedKey.Bytes(), SendAsRetry: true},
		{Config: echConfig, PrivateKey: echKey.Bytes(), SendAsRetry: true},
	}

	check()
}

func TestMessageSigner(t *testing.T) {
	t.Run("TLSv10", func(t *testing.T) { testMessageSigner(t, VersionTLS10) })
	t.Run("TLSv12", func(t *testing.T) { testMessageSigner(t, VersionTLS12) })
	t.Run("TLSv13", func(t *testing.T) { testMessageSigner(t, VersionTLS13) })
}

func testMessageSigner(t *testing.T, version uint16) {
	clientConfig, serverConfig := testConfigClient.Clone(), testConfigServer.Clone()
	serverConfig.ClientAuth = RequireAnyClientCert
	clientConfig.MinVersion = version
	clientConfig.MaxVersion = version
	serverConfig.MinVersion = version
	serverConfig.MaxVersion = version
	clientConfig.Certificates = []Certificate{{
		Certificate: testClientRSA2048Cert.Certificate,
		PrivateKey:  messageOnlySigner{testClientRSA2048Key},
	}}
	serverConfig.Certificates = []Certificate{{
		Certificate: testRSA2048Cert.Certificate,
		PrivateKey:  messageOnlySigner{testRSA2048Key},
	}}

	_, _, err := testHandshake(t, clientConfig, serverConfig)
	if version < VersionTLS12 {
		if err == nil {
			t.Fatal("expected failure for TLS 1.0/1.1")
		}
	} else {
		if err != nil {
			t.Fatalf("unexpected failure: %s", err)
		}
	}

	clientConfig.Certificates = []Certificate{{
		Certificate: testClientECDSAP256Cert.Certificate,
		PrivateKey:  messageOnlySigner{testClientECDSAP256Key},
	}}
	serverConfig.Certificates = []Certificate{{
		Certificate: testECDSAP256Cert.Certificate,
		PrivateKey:  messageOnlySigner{testECDSAP256Key},
	}}

	_, _, err = testHandshake(t, clientConfig, serverConfig)
	if version < VersionTLS12 {
		if err == nil {
			t.Fatal("expected failure for TLS 1.0/1.1")
		}
	} else {
		if err != nil {
			t.Fatalf("unexpected failure: %s", err)
		}
	}
}

type messageOnlySigner struct{ crypto.Signer }

func (s messageOnlySigner) Public() crypto.PublicKey {
	return s.Signer.Public()
}

func (s messageOnlySigner) Sign(rand io.Reader, msg []byte, opts crypto.SignerOpts) (signature []byte, err error) {
	return nil, errors.New("messageOnlySigner: Sign called")
}

func (s messageOnlySigner) SignMessage(rand io.Reader, msg []byte, opts crypto.SignerOpts) (signature []byte, err error) {
	h := opts.HashFunc().New()
	h.Write(msg)
	digest := h.Sum(nil)
	return s.Signer.Sign(rand, digest, opts)
}

// bitFlippingSigner wraps a crypto.Signer and flips a bit in the signature,
// producing an invalid signature.
type bitFlippingSigner struct{ crypto.Signer }

func (s bitFlippingSigner) Public() crypto.PublicKey {
	return s.Signer.Public()
}

func (s bitFlippingSigner) Sign(rand io.Reader, digest []byte, opts crypto.SignerOpts) ([]byte, error) {
	sig, err := s.Signer.Sign(rand, digest, opts)
	if err != nil {
		return nil, err
	}
	sig[0] ^= 1
	return sig, nil
}

// TestInvalidHandshakeSignature tests that invalid handshake signatures are
// rejected for all TLS versions, for both server and client certificates,
// even when InsecureSkipVerify or RequireAnyClientCert are used (which disable
// certificate chain verification, but not signature verification).
func TestInvalidHandshakeSignature(t *testing.T) {
	t.Run("TLSv10", func(t *testing.T) {
		skipFIPS(t)
		testInvalidHandshakeSignature(t, VersionTLS10)
	})
	t.Run("TLSv12", func(t *testing.T) { testInvalidHandshakeSignature(t, VersionTLS12) })
	t.Run("TLSv13", func(t *testing.T) { testInvalidHandshakeSignature(t, VersionTLS13) })
}

func testInvalidHandshakeSignature(t *testing.T, version uint16) {
	serverConfig := testConfigServer.Clone()
	serverConfig.MaxVersion = version
	serverConfig.MinVersion = version
	serverConfig.SessionTicketsDisabled = true
	clientConfig := testConfigClient.Clone()
	clientConfig.MaxVersion = version
	clientConfig.MinVersion = version

	// Test that the server rejects invalid client certificate signatures,
	// even when RequireAnyClientCert is used.
	t.Run("ClientSignature", func(t *testing.T) {
		serverConfig := serverConfig.Clone()
		serverConfig.ClientAuth = RequireAnyClientCert
		clientConfig := clientConfig.Clone()
		clientConfig.Certificates = []Certificate{{
			Certificate: testClientECDSAP256Cert.Certificate,
			PrivateKey:  bitFlippingSigner{testClientECDSAP256Cert.PrivateKey.(crypto.Signer)},
		}}

		clientErr, serverErr := testInvalidSignatureHandshake(t, clientConfig, serverConfig)
		if serverErr == nil {
			t.Fatalf("expected server to reject invalid client signature; client err = %v", clientErr)
		}
		if !strings.Contains(serverErr.Error(), "invalid signature") {
			t.Errorf("expected 'invalid signature' error, got: %v", serverErr)
		}
	})

	// Test that the client rejects invalid server certificate signatures.
	t.Run("ServerSignature", func(t *testing.T) {
		serverConfig := serverConfig.Clone()
		serverConfig.Certificates = []Certificate{{
			Certificate: testRSA2048Cert.Certificate,
			PrivateKey:  bitFlippingSigner{testRSA2048Cert.PrivateKey.(crypto.Signer)},
		}}

		clientErr, serverErr := testInvalidSignatureHandshake(t, clientConfig, serverConfig)
		if clientErr == nil {
			t.Fatalf("expected client to reject invalid server signature; server err = %v", serverErr)
		}
		if !strings.Contains(clientErr.Error(), "invalid signature") {
			t.Errorf("expected 'invalid signature' error, got: %v", clientErr)
		}
	})

	// Test that InsecureSkipVerify doesn't disable server signature verification.
	t.Run("ServerSignature/InsecureSkipVerify", func(t *testing.T) {
		clientConfig := clientConfig.Clone()
		clientConfig.InsecureSkipVerify = true
		serverConfig := serverConfig.Clone()
		serverConfig.Certificates = []Certificate{{
			Certificate: testRSA2048Cert.Certificate,
			PrivateKey:  bitFlippingSigner{testRSA2048Cert.PrivateKey.(crypto.Signer)},
		}}

		clientErr, serverErr := testInvalidSignatureHandshake(t, clientConfig, serverConfig)
		if clientErr == nil {
			t.Fatalf("expected client to reject invalid server signature despite InsecureSkipVerify; server err = %v", serverErr)
		}
		if !strings.Contains(clientErr.Error(), "invalid signature") {
			t.Errorf("expected 'invalid signature' error, got: %v", clientErr)
		}
	})
}

// testInvalidSignatureHandshake performs a TLS handshake and returns the
// errors from both client and server. Unlike testHandshake, it doesn't try
// to exchange data after the handshake.
func testInvalidSignatureHandshake(t *testing.T, clientConfig, serverConfig *Config) (clientErr, serverErr error) {
	c, s := localPipe(t)
	done := make(chan struct{})
	go func() {
		defer close(done)
		clientErr = Client(c, clientConfig).Handshake()
		c.Close()
	}()
	serverErr = Server(s, serverConfig).Handshake()
	s.Close()
	<-done
	return
}

func TestKeyLogWriterErr(t *testing.T) {
	var f *os.File // typed nil
	err := (&Config{KeyLogWriter: f}).writeKeyLog("CLIENT_RANDOM", make([]byte, 32), make([]byte, 48))
	if err == nil {
		t.Fatal("writeKeyLog: expected error, got nil")
	}

	if want := os.ErrInvalid; !errors.Is(err, os.ErrInvalid) {
		t.Errorf("got %v, want %v", err, want)
	}
	if got, want := err.Error(), "KeyLogWriter"; !strings.Contains(got, want) {
		t.Errorf("got %q, want %q", got, want)
	}
}

func testLocalCertificate(t *testing.T, version uint16, callback bool) {
	clientConfig, serverConfig := testConfigClient.Clone(), testConfigServer.Clone()

	clientConfig.MinVersion, serverConfig.MinVersion = version, version
	clientConfig.MaxVersion, serverConfig.MaxVersion = version, version
	if version < VersionTLS12 {
		skipFIPS(t)
	}
	serverConfig.ClientAuth = RequestClientCert

	serverCert, clientCert := testConfigServer.Certificates[0], testConfigClient.Certificates[0]

	if callback {
		clientConfig.GetClientCertificate = func(_ *CertificateRequestInfo) (*Certificate, error) {
			return &Certificate{
				Certificate: clientCert.Certificate,
				PrivateKey:  clientCert.PrivateKey,
			}, nil
		}
		clientConfig.Certificates = nil
		serverConfig.GetCertificate = func(_ *ClientHelloInfo) (*Certificate, error) {
			return &Certificate{
				Certificate: serverCert.Certificate,
				PrivateKey:  serverCert.PrivateKey,
			}, nil
		}
		serverConfig.Certificates = nil
	}

	ss, cs, err := testHandshake(t, clientConfig, serverConfig)
	if err != nil {
		t.Fatalf("unexpected failure: %s", err)
	}

	if !slices.EqualFunc(ss.LocalCertificate, serverCert.Certificate, bytes.Equal) {
		t.Errorf("unexpected server local certificate: %x, want %x", ss.LocalCertificate, serverCert.Certificate)
	}

	if !slices.EqualFunc(cs.LocalCertificate, clientCert.Certificate, bytes.Equal) {
		t.Errorf("unexpected client local certificate: %x, want %x", cs.LocalCertificate, clientCert.Certificate)
	}
}

func TestLocalCertificate(t *testing.T) {
	for _, useCallback := range []bool{true, false} {
		name := "UseCertificates"
		if useCallback {
			name = "UseCallbacks"
		}
		t.Run(name, func(t *testing.T) {
			for _, v := range []uint16{VersionTLS10, VersionTLS11, VersionTLS12, VersionTLS13} {
				t.Run(VersionName(v), func(t *testing.T) {
					testLocalCertificate(t, v, useCallback)
				})
			}
		})
	}
}

func testLocalCertificateResumption(t *testing.T, version uint16, callback bool) {
	clientConfig, serverConfig := testConfigClient.Clone(), testConfigServer.Clone()

	clientConfig.MinVersion, serverConfig.MinVersion = version, version
	clientConfig.MaxVersion, serverConfig.MaxVersion = version, version
	if version < VersionTLS12 {
		skipFIPS(t)
	}
	clientConfig.ClientSessionCache = NewLRUClientSessionCache(1)
	serverConfig.ClientAuth = RequestClientCert

	serverCert, clientCert := testConfigServer.Certificates[0], testConfigClient.Certificates[0]

	if callback {
		clientConfig.GetClientCertificate = func(_ *CertificateRequestInfo) (*Certificate, error) {
			return &Certificate{
				Certificate: clientCert.Certificate,
				PrivateKey:  clientCert.PrivateKey,
			}, nil
		}
		clientConfig.Certificates = nil
		serverConfig.GetCertificate = func(_ *ClientHelloInfo) (*Certificate, error) {
			return &Certificate{
				Certificate: serverCert.Certificate,
				PrivateKey:  serverCert.PrivateKey,
			}, nil
		}
		serverConfig.Certificates = nil
	}

	if _, _, err := testHandshake(t, clientConfig, serverConfig); err != nil {
		t.Fatalf("first handshake failed: %s", err)
	}

	ss, cs, err := testHandshake(t, clientConfig, serverConfig)
	if err != nil {
		t.Fatalf("second handshake failed: %s", err)
	}
	if !ss.DidResume || !cs.DidResume {
		t.Fatalf("second handshake did not resume (server=%v client=%v)", ss.DidResume, cs.DidResume)
	}
	if ss.LocalCertificate != nil {
		t.Errorf("server LocalCertificate on resumed connection: got %x, want nil", ss.LocalCertificate)
	}
	if cs.LocalCertificate != nil {
		t.Errorf("client LocalCertificate on resumed connection: got %x, want nil", cs.LocalCertificate)
	}
}

func TestLocalCertificateResumption(t *testing.T) {
	for _, useCallback := range []bool{true, false} {
		name := "UseCertificates"
		if useCallback {
			name = "UseCallbacks"
		}
		t.Run(name, func(t *testing.T) {
			for _, v := range []uint16{VersionTLS10, VersionTLS11, VersionTLS12, VersionTLS13} {
				t.Run(VersionName(v), func(t *testing.T) {
					testLocalCertificateResumption(t, v, useCallback)
				})
			}
		})
	}
}
