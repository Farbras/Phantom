package brrr

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"sync"
	"testing"

	"github.com/molecule-man/go-brrr/internal/creftest"
	"github.com/molecule-man/go-brrr/internal/encoder"
)

// writerLevels are the quality levels exercised by round-trip tests.
var writerLevels = []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

func TestWriterMultipleWrites(t *testing.T) {
	// Write data in multiple small chunks, then close.
	input := bytes.Repeat([]byte("The quick brown fox jumps over the lazy dog. "), 100)

	for _, level := range writerLevels {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriter(&buf, level)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}

			// Write in 100-byte chunks.
			for i := 0; i < len(input); i += 100 {
				end := min(i+100, len(input))
				_, err := w.Write(input[i:end])
				if err != nil {
					t.Fatalf("Write: %v", err)
				}
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}

			decompressed := creftest.BrotliDecompress(t, buf.Bytes())
			if !bytes.Equal(decompressed, input) {
				t.Errorf("round-trip mismatch: got %d bytes, want %d bytes",
					len(decompressed), len(input))
			}
		})
	}
}

func TestWriterFlush(t *testing.T) {
	// Write some data, flush, write more, close.
	part1 := []byte("first part of the data, hello world! ")
	part2 := bytes.Repeat([]byte("second part repeated "), 50)
	want := make([]byte, 0, len(part1)+len(part2))
	want = append(want, part1...)
	want = append(want, part2...)

	for _, level := range writerLevels {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriter(&buf, level)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}

			_, err = w.Write(part1)
			if err != nil {
				t.Fatalf("Write part1: %v", err)
			}
			if err := w.Flush(); err != nil {
				t.Fatalf("Flush: %v", err)
			}

			// After flush, some data should have been written.
			if buf.Len() == 0 {
				t.Fatal("expected output after Flush, got none")
			}

			_, err = w.Write(part2)
			if err != nil {
				t.Fatalf("Write part2: %v", err)
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}

			decompressed := creftest.BrotliDecompress(t, buf.Bytes())
			if !bytes.Equal(decompressed, want) {
				t.Errorf("round-trip mismatch: got %d bytes, want %d bytes",
					len(decompressed), len(want))
			}
		})
	}
}

// TestWriterFastChunkedBoundedMemory feeds the q0/q1 fast path far more input
// than one fragment (1<<lgwin) in small chunks, forcing Write to drain full
// fragments mid-stream rather than buffering the whole input. The compressed
// bytes must be identical to compressing the same input in a single Write, so
// chunking changes neither correctness nor ratio.
func TestWriterFastChunkedBoundedMemory(t *testing.T) {
	const lgwin = 10 // fragment size 1<<10 = 1024 bytes
	input := bytes.Repeat([]byte("The quick brown fox jumps over the lazy dog. "), 2000)

	compressOnce := func(t *testing.T, level int, chunk int) []byte {
		t.Helper()
		var buf bytes.Buffer
		w, err := NewWriterOptions(&buf, level, WriterOptions{LGWin: lgwin})
		if err != nil {
			t.Fatalf("NewWriter: %v", err)
		}
		if chunk == 0 {
			chunk = len(input)
		}
		for i := 0; i < len(input); i += chunk {
			end := min(i+chunk, len(input))
			if _, err := w.Write(input[i:end]); err != nil {
				t.Fatalf("Write: %v", err)
			}
		}
		if err := w.Close(); err != nil {
			t.Fatalf("Close: %v", err)
		}
		return buf.Bytes()
	}

	for _, level := range []int{0, 1} {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			oneShot := compressOnce(t, level, 0)
			chunked := compressOnce(t, level, 100)

			if !bytes.Equal(chunked, oneShot) {
				t.Errorf("chunked output differs from single-shot: %d vs %d bytes",
					len(chunked), len(oneShot))
			}
			decompressed := creftest.BrotliDecompress(t, chunked)
			if !bytes.Equal(decompressed, input) {
				t.Errorf("round-trip mismatch: got %d bytes, want %d bytes",
					len(decompressed), len(input))
			}
		})
	}
}

// TestWriterFastFlushAfterDrain exercises a Flush on the q0/q1 fast path after
// Write has already drained full fragments mid-stream, so flushCarry must
// byte-align the continued bitstream correctly.
func TestWriterFastFlushAfterDrain(t *testing.T) {
	const lgwin = 10
	part1 := bytes.Repeat([]byte("alpha beta gamma delta "), 300) // > many fragments
	part2 := bytes.Repeat([]byte("epsilon zeta eta theta "), 300)
	want := append(append([]byte{}, part1...), part2...)

	for _, level := range []int{0, 1} {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriterOptions(&buf, level, WriterOptions{LGWin: lgwin})
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			for i := 0; i < len(part1); i += 100 {
				end := min(i+100, len(part1))
				if _, err := w.Write(part1[i:end]); err != nil {
					t.Fatalf("Write part1: %v", err)
				}
			}
			if err := w.Flush(); err != nil {
				t.Fatalf("Flush: %v", err)
			}
			for i := 0; i < len(part2); i += 100 {
				end := min(i+100, len(part2))
				if _, err := w.Write(part2[i:end]); err != nil {
					t.Fatalf("Write part2: %v", err)
				}
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}

			decompressed := creftest.BrotliDecompress(t, buf.Bytes())
			if !bytes.Equal(decompressed, want) {
				t.Errorf("round-trip mismatch: got %d bytes, want %d bytes",
					len(decompressed), len(want))
			}
		})
	}
}

func TestWriterEmpty(t *testing.T) {
	// Closing without writing any data should produce a valid empty stream.
	for _, level := range writerLevels {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriter(&buf, level)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}

			decompressed := creftest.BrotliDecompress(t, buf.Bytes())
			if len(decompressed) != 0 {
				t.Errorf("expected empty output, got %d bytes: %q", len(decompressed), decompressed)
			}
		})
	}
}

func TestWriterReset(t *testing.T) {
	input1 := []byte("first stream content")
	input2 := []byte("second stream content, different data")

	for _, level := range writerLevels {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf1, buf2 bytes.Buffer
			w, err := NewWriter(&buf1, level)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}

			_, err = w.Write(input1)
			if err != nil {
				t.Fatalf("Write 1: %v", err)
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close 1: %v", err)
			}

			// Reset and compress different data.
			w.Reset(&buf2)
			_, err = w.Write(input2)
			if err != nil {
				t.Fatalf("Write 2: %v", err)
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close 2: %v", err)
			}

			dec1 := creftest.BrotliDecompress(t, buf1.Bytes())
			if !bytes.Equal(dec1, input1) {
				t.Errorf("stream 1 mismatch: got %q, want %q", dec1, input1)
			}

			dec2 := creftest.BrotliDecompress(t, buf2.Bytes())
			if !bytes.Equal(dec2, input2) {
				t.Errorf("stream 2 mismatch: got %q, want %q", dec2, input2)
			}
		})
	}
}

func TestWriterResetSizeHint(t *testing.T) {
	input := readTestdata(t, filepath.Join("brotli-ref", "tests", "testdata", "alice29.txt"))
	const bigHint = 4 << 20 // q5 selects the large input hasher

	pd, err := PrepareDictionary([]byte("Alice was beginning to get very tired"))
	if err != nil {
		t.Fatalf("PrepareDictionary: %v", err)
	}

	compress := func(t *testing.T, w *Writer, dst *bytes.Buffer) []byte {
		t.Helper()
		if _, err := w.Write(input); err != nil {
			t.Fatalf("Write: %v", err)
		}
		if err := w.Close(); err != nil {
			t.Fatalf("Close: %v", err)
		}
		return bytes.Clone(dst.Bytes())
	}
	fresh := func(t *testing.T, level int, opts WriterOptions) []byte {
		t.Helper()
		var buf bytes.Buffer
		w, err := NewWriterOptions(&buf, level, opts)
		if err != nil {
			t.Fatalf("NewWriterOptions: %v", err)
		}
		return compress(t, w, &buf)
	}

	for _, level := range writerLevels {
		for _, dicts := range [][]*PreparedDictionary{nil, {pd}} {
			if dicts != nil && level < 2 {
				continue
			}
			t.Run(fmt.Sprintf("quality_%d/dicts_%d", level, len(dicts)), func(t *testing.T) {
				noHint := fresh(t, level, WriterOptions{Dictionaries: dicts})
				withHint := fresh(t, level, WriterOptions{Dictionaries: dicts, SizeHint: bigHint})
				if level == 5 && bytes.Equal(noHint, withHint) {
					t.Fatal("the hint does not change the output")
				}

				var buf bytes.Buffer
				w, err := NewWriterOptions(&buf, level, WriterOptions{Dictionaries: dicts, SizeHint: bigHint})
				if err != nil {
					t.Fatalf("NewWriterOptions: %v", err)
				}
				if got := compress(t, w, &buf); !bytes.Equal(got, withHint) {
					t.Fatalf("first stream: %s", firstDiff(got, withHint))
				}

				// The first Reset reacquires the compressor. Later resets reuse it.
				steps := []struct {
					name  string
					reset func(dst io.Writer)
					want  []byte
				}{
					{"Reset after the options hint", w.Reset, noHint},
					{"ResetWithSizeHint", func(dst io.Writer) { w.ResetWithSizeHint(dst, bigHint) }, withHint},
					{"Reset after ResetWithSizeHint", w.Reset, noHint},
				}
				for _, step := range steps {
					buf.Reset()
					step.reset(&buf)
					if got := compress(t, w, &buf); !bytes.Equal(got, step.want) {
						t.Fatalf("%s: %s", step.name, firstDiff(got, step.want))
					}
				}
			})
		}
	}
}

func TestWriterCloseIdempotent(t *testing.T) {
	var buf bytes.Buffer
	w, _ := NewWriter(&buf, 0)
	_, _ = w.Write([]byte("data"))
	if err := w.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	// Second close should not error.
	if err := w.Close(); err != nil {
		t.Fatalf("second Close: %v", err)
	}
}

func TestWriterWriteAfterClose(t *testing.T) {
	var buf bytes.Buffer
	w, _ := NewWriter(&buf, 0)
	if err := w.Close(); err != nil {
		t.Fatalf("Close: %v", err)
	}
	_, err := w.Write([]byte("data"))
	if !errors.Is(err, io.ErrClosedPipe) {
		t.Fatalf("Write after Close: got err %v, want io.ErrClosedPipe", err)
	}
}

func TestWriterIOWriter(t *testing.T) {
	// Verify Writer satisfies io.WriteCloser at compile time.
	var _ io.WriteCloser = (*Writer)(nil)
}

func TestNewWriterValidation(t *testing.T) {
	// Valid options.
	for _, level := range []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} {
		w, err := NewWriter(io.Discard, level)
		if err != nil {
			t.Errorf("NewWriter(quality=%d): unexpected error: %v", level, err)
		}
		if w == nil {
			t.Errorf("NewWriter(quality=%d): returned nil writer", level)
		}
	}

	// Invalid quality.
	for _, level := range []int{-1, 12, 100} {
		w, err := NewWriter(io.Discard, level)
		if err == nil {
			t.Errorf("NewWriter(quality=%d): expected error, got nil", level)
		}
		if w != nil {
			t.Errorf("NewWriter(quality=%d): expected nil writer, got non-nil", level)
		}
	}

	// Invalid lgwin.
	for _, lgwin := range []int{5, 9, 25, 30} {
		w, err := NewWriterOptions(io.Discard, 0, WriterOptions{LGWin: lgwin})
		if err == nil {
			t.Errorf("NewWriter(lgwin=%d): expected error, got nil", lgwin)
		}
		if w != nil {
			t.Errorf("NewWriter(lgwin=%d): expected nil writer, got non-nil", lgwin)
		}
	}

	// Valid lgwin values.
	for lgwin := 10; lgwin <= 24; lgwin++ {
		w, err := NewWriterOptions(io.Discard, 0, WriterOptions{LGWin: lgwin})
		if err != nil {
			t.Errorf("NewWriter(lgwin=%d): unexpected error: %v", lgwin, err)
		}
		if w == nil {
			t.Errorf("NewWriter(lgwin=%d): returned nil writer", lgwin)
		}
	}
}

func TestWriterErrorPropagation(t *testing.T) {
	errFail := errors.New("write failed")
	// failAfter returns an io.Writer that fails after n bytes have been written.
	failAfter := func(n int) io.Writer {
		return &limitedWriter{limit: n, err: errFail}
	}

	// Generate enough data to force the streaming encoder to flush.
	input := bytes.Repeat([]byte("abcdefghijklmnopqrstuvwxyz0123456789 "), 2000)

	// Test Write error propagation for streaming qualities (>= 2).
	// The streaming encoder needs a full ring buffer before it emits
	// compressed data. Write repeatedly until the error surfaces.
	for _, quality := range []int{2, 4, 6} {
		t.Run(fmt.Sprintf("write_q%d", quality), func(t *testing.T) {
			w, err := NewWriterOptions(failAfter(0), quality, WriterOptions{LGWin: 10})
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			var writeErr error
			for range 1000 {
				_, writeErr = w.Write(input)
				if writeErr != nil {
					break
				}
			}
			if !errors.Is(writeErr, errFail) {
				t.Errorf("Write: got err %v, want %v", writeErr, errFail)
			}
		})
	}

	// Test Close error propagation for streaming qualities.
	for _, quality := range []int{2, 4, 6} {
		t.Run(fmt.Sprintf("close_q%d", quality), func(t *testing.T) {
			w, err := NewWriter(failAfter(0), quality)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			err = w.Close()
			if !errors.Is(err, errFail) {
				t.Errorf("Close: got err %v, want %v", err, errFail)
			}
		})
	}

	// Test Flush error propagation for streaming qualities.
	for _, quality := range []int{2, 4} {
		t.Run(fmt.Sprintf("flush_q%d", quality), func(t *testing.T) {
			w, err := NewWriter(failAfter(0), quality)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			_, _ = w.Write([]byte("some data to flush"))
			err = w.Flush()
			if !errors.Is(err, errFail) {
				t.Errorf("Flush: got err %v, want %v", err, errFail)
			}
		})
	}

	// Test Flush and Close error propagation for batch qualities (0-1).
	for _, quality := range []int{0, 1} {
		t.Run(fmt.Sprintf("flush_q%d", quality), func(t *testing.T) {
			w, err := NewWriter(failAfter(0), quality)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			_, _ = w.Write([]byte("some data"))
			err = w.Flush()
			if !errors.Is(err, errFail) {
				t.Errorf("Flush: got err %v, want %v", err, errFail)
			}
		})

		t.Run(fmt.Sprintf("close_q%d", quality), func(t *testing.T) {
			w, err := NewWriter(failAfter(0), quality)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			_, _ = w.Write([]byte("some data"))
			err = w.Close()
			if !errors.Is(err, errFail) {
				t.Errorf("Close: got err %v, want %v", err, errFail)
			}
		})
	}
}

func TestWriterDictionaryLowQuality(t *testing.T) {
	pd, err := PrepareDictionary([]byte("dictionary data"))
	if err != nil {
		t.Fatalf("PrepareDictionary: %v", err)
	}
	for _, quality := range []int{0, 1} {
		t.Run(fmt.Sprintf("quality_%d", quality), func(t *testing.T) {
			_, err := NewWriterOptions(io.Discard, quality, WriterOptions{
				Dictionaries: []*PreparedDictionary{pd},
			})
			if !errors.Is(err, encoder.ErrQualityTooLow) {
				t.Fatalf("expected encoder.ErrQualityTooLow for level %d, got %v", quality, err)
			}
		})
	}
}

func TestWriterDictionaryTooMany(t *testing.T) {
	dicts := make([]*PreparedDictionary, 16)
	for i := range dicts {
		pd, err := PrepareDictionary(fmt.Appendf(nil, "dict%d___", i))
		if err != nil {
			t.Fatalf("PrepareDictionary %d: %v", i, err)
		}
		dicts[i] = pd
	}
	_, err := NewWriterOptions(io.Discard, 4, WriterOptions{
		Dictionaries: dicts,
	})
	if !errors.Is(err, encoder.ErrTooManyDicts) {
		t.Fatalf("expected encoder.ErrTooManyDicts, got %v", err)
	}
}

func TestWriterFlushAfterClose(t *testing.T) {
	var buf bytes.Buffer
	w, _ := NewWriter(&buf, 0)
	_ = w.Close()
	err := w.Flush()
	if !errors.Is(err, io.ErrClosedPipe) {
		t.Fatalf("Flush after Close: got err %v, want io.ErrClosedPipe", err)
	}
}

func TestWriterFlushEmpty(t *testing.T) {
	// Flush with no buffered data should be a no-op for batch qualities.
	for _, quality := range []int{0, 1} {
		t.Run(fmt.Sprintf("quality_%d", quality), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriter(&buf, quality)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			if err := w.Flush(); err != nil {
				t.Fatalf("Flush: %v", err)
			}
			if buf.Len() != 0 {
				t.Errorf("expected no output from empty flush, got %d bytes", buf.Len())
			}
		})
	}
}

// limitedWriter is an io.Writer that returns an error after limit bytes.
type limitedWriter struct {
	written int
	limit   int
	err     error
}

func (w *limitedWriter) Write(p []byte) (int, error) {
	if w.written+len(p) > w.limit {
		remaining := w.limit - w.written
		if remaining > 0 {
			w.written += remaining
			return remaining, w.err
		}
		return 0, w.err
	}
	w.written += len(p)
	return len(p), nil
}

func TestWriterErrorStickiness(t *testing.T) {
	// After a write error surfaces, subsequent Write, Flush, and Close
	// must return the same cached error without attempting further I/O.
	errFail := errors.New("disk full")

	for _, quality := range []int{0, 1, 2, 4} {
		t.Run(fmt.Sprintf("quality_%d", quality), func(t *testing.T) {
			// Allow a small amount of output so the writer initialises,
			// then fail on subsequent writes.
			w, err := NewWriterOptions(&limitedWriter{limit: 0, err: errFail}, quality, WriterOptions{LGWin: 10})
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}

			// Push data until the error surfaces through Write or Close.
			input := bytes.Repeat([]byte("abcdefghijklmnop"), 5000)
			var firstErr error
			for range 200 {
				_, firstErr = w.Write(input)
				if firstErr != nil {
					break
				}
			}
			if firstErr == nil {
				// For batch qualities (0-1) the error only appears on Flush/Close.
				firstErr = w.Close()
			}
			if !errors.Is(firstErr, errFail) {
				t.Fatalf("expected initial error %v, got %v", errFail, firstErr)
			}

			// Subsequent Write must return the cached error.
			_, err = w.Write([]byte("more data"))
			if !errors.Is(err, errFail) {
				t.Errorf("Write after error: got %v, want %v", err, errFail)
			}

			// Subsequent Flush must return the cached error.
			err = w.Flush()
			if !errors.Is(err, errFail) {
				t.Errorf("Flush after error: got %v, want %v", err, errFail)
			}

			// Subsequent Close must return the cached error.
			err = w.Close()
			if !errors.Is(err, errFail) {
				t.Errorf("Close after error: got %v, want %v", err, errFail)
			}
		})
	}
}

func TestWriterResetQ6WithCompoundDict(t *testing.T) {
	dict := bytes.Repeat([]byte("dictionary content for compound test "), 50)
	input := bytes.Repeat([]byte("input referencing dictionary content here "), 100)
	pd, err := PrepareDictionary(dict)
	if err != nil {
		t.Fatalf("PrepareDictionary: %v", err)
	}
	dictOpts := WriterOptions{Dictionaries: []*PreparedDictionary{pd}}

	// Compress with a fresh writer + compound dictionary.
	var freshBuf bytes.Buffer
	fresh, err := NewWriterOptions(&freshBuf, 6, dictOpts)
	if err != nil {
		t.Fatalf("NewWriterOptions (fresh): %v", err)
	}
	if _, err := fresh.Write(input); err != nil {
		t.Fatalf("Write (fresh): %v", err)
	}
	if err := fresh.Close(); err != nil {
		t.Fatalf("Close (fresh): %v", err)
	}

	// Use a reused writer: first compress something to dirty internal state,
	// then Reset and compress the same input. The dictionary supplied via
	// WriterOptions must be preserved across Reset.
	var discardBuf, reusedBuf bytes.Buffer
	reused, err := NewWriterOptions(&discardBuf, 6, dictOpts)
	if err != nil {
		t.Fatalf("NewWriterOptions (reused): %v", err)
	}
	if _, err := reused.Write([]byte("throwaway data to dirty state")); err != nil {
		t.Fatalf("Write (throwaway): %v", err)
	}
	if err := reused.Close(); err != nil {
		t.Fatalf("Close (throwaway): %v", err)
	}

	reused.Reset(&reusedBuf)
	if _, err := reused.Write(input); err != nil {
		t.Fatalf("Write (reused): %v", err)
	}
	if err := reused.Close(); err != nil {
		t.Fatalf("Close (reused): %v", err)
	}

	// A reused writer with the same dictionary and input must produce
	// byte-identical output to a fresh writer.
	if !bytes.Equal(freshBuf.Bytes(), reusedBuf.Bytes()) {
		t.Errorf("output mismatch: fresh=%d bytes, reused=%d bytes",
			freshBuf.Len(), reusedBuf.Len())
	}
}

// TestPreparedDictionaryConcurrentShare exercises the documented contract that
// a *PreparedDictionary may be shared across goroutines. Run with -race.
func TestPreparedDictionaryConcurrentShare(t *testing.T) {
	dict := bytes.Repeat([]byte("shared-dictionary content for concurrency test "), 100)
	input := bytes.Repeat([]byte("payload that references shared-dictionary content "), 200)

	pd, err := PrepareDictionary(dict)
	if err != nil {
		t.Fatalf("PrepareDictionary: %v", err)
	}

	const goroutines = 8
	var wg sync.WaitGroup
	wg.Add(goroutines)
	for range goroutines {
		go func() {
			defer wg.Done()
			var buf bytes.Buffer
			w, err := NewWriterOptions(&buf, 6, WriterOptions{
				Dictionaries: []*PreparedDictionary{pd},
			})
			if err != nil {
				t.Errorf("NewWriterOptions: %v", err)
				return
			}
			if _, err := w.Write(input); err != nil {
				t.Errorf("Write: %v", err)
				return
			}
			if err := w.Close(); err != nil {
				t.Errorf("Close: %v", err)
			}
		}()
	}
	wg.Wait()
}

func TestCompress(t *testing.T) {
	inputs := map[string][]byte{
		"empty": nil,
		"short": []byte("Hello, brotli!"),
		"repetitive": bytes.Repeat(
			[]byte("The quick brown fox jumps over the lazy dog. "), 200),
	}

	for name, input := range inputs {
		for _, level := range append(writerLevels, 11) {
			compressed, err := Compress(input, level)
			if err != nil {
				t.Fatalf("Compress(%s, level=%d): %v", name, level, err)
			}
			got, err := Decompress(compressed)
			if err != nil {
				t.Fatalf("Decompress(%s, level=%d): %v", name, level, err)
			}
			if !bytes.Equal(got, input) {
				t.Errorf("round-trip(%s, level=%d): got %d bytes, want %d",
					name, level, len(got), len(input))
			}
		}
	}
}

func TestCompressInvalidLevel(t *testing.T) {
	for _, level := range []int{-1, 12, 100} {
		out, err := Compress([]byte("data"), level)
		if err == nil {
			t.Errorf("Compress(level=%d): expected error, got nil", level)
		}
		if out != nil {
			t.Errorf("Compress(level=%d): expected nil output, got %d bytes", level, len(out))
		}
	}
}

// TestWriterFlushPrefixIsDecodable checks the property Flush exists for: after
// it returns, everything written so far must be recoverable from the bytes on
// the wire, without waiting for Close.
//
// The other flush tests decode only after Close, which hides a stream that is
// not byte-aligned at the flush point: Close emits the retained bits and the
// full stream comes out correct. A streaming consumer — an HTTP client reading
// a chunked response, say — never gets that far.
//
// This mirrors BROTLI_OPERATION_FLUSH in the reference encoder: "When flush is
// complete, output data will be sufficient for decoder to reproduce all the
// given input."
func TestWriterFlushPrefixIsDecodable(t *testing.T) {
	// Several shapes and sizes: how many bits are left pending at the flush
	// point depends on the content, so a single payload can pass by luck.
	payloads := map[string][]byte{
		"repetitive": bytes.Repeat([]byte("the quick brown fox jumps over the lazy dog. "), 300),
		"json":       bytes.Repeat([]byte(`{"result":"0xdeadbeef","id":1},`), 400),
		"short":      []byte("hello brotli"),
		"binary": func() []byte {
			b := make([]byte, 4096)
			for i := range b {
				b[i] = byte(i * 7)
			}
			return b
		}(),
	}

	for _, level := range writerLevels {
		for name, want := range payloads {
			t.Run(fmt.Sprintf("quality_%d/%s", level, name), func(t *testing.T) {
				var buf bytes.Buffer
				w, err := NewWriter(&buf, level)
				if err != nil {
					t.Fatalf("NewWriter: %v", err)
				}
				if _, err := w.Write(want); err != nil {
					t.Fatalf("Write: %v", err)
				}
				if err := w.Flush(); err != nil {
					t.Fatalf("Flush: %v", err)
				}

				// Decode only what the flush put on the wire. The stream is
				// unterminated, so a decoder reports a truncated input at the
				// end; the bytes recovered before that are what matters.
				flushed := append([]byte(nil), buf.Bytes()...)
				got, _ := io.ReadAll(NewReader(bytes.NewReader(flushed)))
				if !bytes.Equal(got, want) {
					t.Errorf("flushed prefix decoded to %d of %d bytes", len(got), len(want))
				}

				// The stream must still finish correctly afterwards.
				if err := w.Close(); err != nil {
					t.Fatalf("Close: %v", err)
				}
				full := creftest.BrotliDecompress(t, buf.Bytes())
				if !bytes.Equal(full, want) {
					t.Errorf("after Close: got %d bytes, want %d", len(full), len(want))
				}
			})
		}
	}
}

// TestWriterRepeatedFlushIsDecodable covers a streaming writer that flushes
// after every chunk, which is what an HTTP handler does.
func TestWriterRepeatedFlushIsDecodable(t *testing.T) {
	chunks := [][]byte{
		[]byte(`{"jsonrpc":"2.0","id":1,"result":[`),
		bytes.Repeat([]byte(`{"a":"0x0000000000000000000000000000000000000001"},`), 40),
		bytes.Repeat([]byte(`{"b":"0xffffffffffffffffffffffffffffffffffffffff"},`), 40),
		[]byte(`{"end":true}]}`),
	}

	for _, level := range writerLevels {
		t.Run(fmt.Sprintf("quality_%d", level), func(t *testing.T) {
			var buf bytes.Buffer
			w, err := NewWriter(&buf, level)
			if err != nil {
				t.Fatalf("NewWriter: %v", err)
			}
			var want []byte
			for i, c := range chunks {
				if _, err := w.Write(c); err != nil {
					t.Fatalf("Write chunk %d: %v", i, err)
				}
				if err := w.Flush(); err != nil {
					t.Fatalf("Flush chunk %d: %v", i, err)
				}
				want = append(want, c...)

				got, _ := io.ReadAll(NewReader(bytes.NewReader(buf.Bytes())))
				if !bytes.Equal(got, want) {
					t.Fatalf("after chunk %d: decoded %d of %d bytes", i, len(got), len(want))
				}
			}
			if err := w.Close(); err != nil {
				t.Fatalf("Close: %v", err)
			}
			full := creftest.BrotliDecompress(t, buf.Bytes())
			if !bytes.Equal(full, want) {
				t.Errorf("after Close: got %d bytes, want %d", len(full), len(want))
			}
		})
	}
}
