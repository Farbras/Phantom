// Copyright 2022 The gVisor Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package metric

import (
	"unsafe"

	"gvisor.dev/gvisor/pkg/atomicbitops"
	"gvisor.dev/gvisor/pkg/gohacks"
	"gvisor.dev/gvisor/pkg/sync"
)

// fieldValueAddress supports ordering retained FieldValue pointers without
// inspecting their strings. As with other pointer ordering in gVisor, this
// relies on Go's nonmoving heap. The addresses are used only for comparisons
// and never converted back into pointers; Field.values keeps the objects live.
// +checkescape:all
//
//go:nosplit
func fieldValueAddress(value *FieldValue) uintptr {
	return uintptr(unsafe.Pointer(value))
}

// snapshotDistribution snapshots the sample data of distribution metrics in
// a non-consistent manner.
// Distribution metrics don't need to be read consistently, because any
// inconsistency (i.e. increments that race with the snapshot) will simply be
// detected during the next snapshot instead. Reading them consistently would
// require more synchronization during increments, which we need to be cheap.
func snapshotDistribution(samples []atomicbitops.Uint64) []uint64 {
	// The number of buckets within a distribution never changes, so there is
	// no race condition from getting the number of buckets upfront.
	numBuckets := len(samples)
	snapshot := make([]uint64, numBuckets)
	if sync.RaceEnabled {
		// runtime.RaceDisable() doesn't actually stop the race detector, so it
		// can't help us here. Instead, call runtime.memmove directly, which is
		// not instrumented by the race detector.
		gohacks.Memmove(unsafe.Pointer(&snapshot[0]), unsafe.Pointer(&samples[0]), unsafe.Sizeof(uint64(0))*uintptr(numBuckets))
	} else {
		for i := range samples {
			snapshot[i] = samples[i].RacyLoad()
		}
	}
	return snapshot
}

// CheapNowNano returns the a timestamp in nanoseconds.
// It is *NOT* measured from the Unix epoch.
// It is monotonic.
//
//go:nosplit
func CheapNowNano() int64 {
	return gohacks.Nanotime()
}
