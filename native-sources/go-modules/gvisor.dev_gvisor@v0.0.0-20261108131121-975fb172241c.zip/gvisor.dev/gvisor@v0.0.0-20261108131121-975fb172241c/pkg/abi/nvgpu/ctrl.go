// Copyright 2023 The gVisor Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package nvgpu

import (
	"structs"
)

// From src/nvidia/interface/deprecated/rmapi_deprecated.h:
const (
	RM_GSS_LEGACY_MASK = 0x00008000
)

// From src/nvidia/inc/kernel/rmapi/param_copy.h:
const (
	// RMAPI_PARAM_COPY_MAX_PARAMS_SIZE is the size limit imposed while copying
	// "embedded pointers" in rmapi parameter structs.
	// See src/nvidia/src/kernel/rmapi/param_copy.c:rmapiParamsAcquire().
	RMAPI_PARAM_COPY_MAX_PARAMS_SIZE = 1 * 1024 * 1024
)

// From src/common/sdk/nvidia/inc/ctrl/ctrlxxxx.h:

// NVXXXX_CTRL_XXX_INFO is typedef-ed as the following in the driver:
// - NV0080_CTRL_GR_INFO
// - NV2080_CTRL_FB_INFO
// - NV2080_CTRL_GR_INFO
// - NV2080_CTRL_BIOS_INFO
// - NV0041_CTRL_SURFACE_INFO
//
// +marshal
type NVXXXX_CTRL_XXX_INFO struct {
	_     structs.HostLayout
	Index uint32
	Data  uint32
}

// CtrlXxxInfoSize is sizeof(NVXXXX_CTRL_XXX_INFO).
var CtrlXxxInfoSize = uint32((*NVXXXX_CTRL_XXX_INFO)(nil).SizeBytes())

// HasCtrlInfoList is a type constraint for parameter structs containing a list
// of NVXXXX_CTRL_XXX_INFO and are simple otherwise.
type HasCtrlInfoList interface {
	ListSize() uint32
	SetCtrlInfoList(ptr P64)
	CtrlInfoList() P64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000client.h:
const (
	NV0000_CTRL_CMD_CLIENT_GET_ADDR_SPACE_TYPE        = 0xd01
	NV0000_CTRL_CMD_CLIENT_SET_INHERITED_SHARE_POLICY = 0xd04
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000event.h:
const (
	NV0000_CTRL_CMD_EVENT_SET_NOTIFICATION = 0x501
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000gpu.h:
const (
	NV0000_CTRL_CMD_GPU_GET_ATTACHED_IDS      = 0x201
	NV0000_CTRL_CMD_GPU_GET_ID_INFO           = 0x202
	NV0000_CTRL_CMD_GPU_GET_DEVICE_IDS        = 0x204
	NV0000_CTRL_CMD_GPU_GET_ID_INFO_V2        = 0x205
	NV0000_CTRL_CMD_GPU_GET_PROBED_IDS        = 0x214
	NV0000_CTRL_CMD_GPU_ATTACH_IDS            = 0x215
	NV0000_CTRL_CMD_GPU_DETACH_IDS            = 0x216
	NV0000_CTRL_CMD_GPU_GET_PCI_INFO          = 0x21b
	NV0000_CTRL_CMD_GPU_GET_UUID_FROM_GPU_ID  = 0x275
	NV0000_CTRL_CMD_GPU_QUERY_DRAIN_STATE     = 0x279
	NV0000_CTRL_CMD_GPU_GET_MEMOP_ENABLE      = 0x27b
	NV0000_CTRL_CMD_GPU_GET_ACTIVE_DEVICE_IDS = 0x288
	NV0000_CTRL_CMD_GPU_ASYNC_ATTACH_ID       = 0x289
	NV0000_CTRL_CMD_GPU_WAIT_ATTACH_ID        = 0x290

	NV0000_CTRL_GPU_INVALID_ID        = 0xffffffff
	NV0000_CTRL_GPU_MAX_PROBED_GPUS   = NV_MAX_DEVICES
	NV0000_CTRL_GPU_MAX_ATTACHED_GPUS = 32
	NV0000_GPU_MAX_GID_LENGTH         = 0x100
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000gpuacct.h:
const (
	NV0000_CTRL_CMD_GPUACCT_GET_ACCOUNTING_STATE = 0xb02
)

// NV0000_CTRL_GPU_GET_ID_INFO_PARAMS is the param type for NV0000_CTRL_CMD_GPU_GET_ID_INFO,
// from src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000gpu.h.
//
// +marshal
type NV0000_CTRL_GPU_GET_ID_INFO_PARAMS struct {
	_                 structs.HostLayout
	GpuID             uint32
	GpuFlags          uint32
	DeviceInstance    uint32
	SubDeviceInstance uint32
	SzName            P64
	SliStatus         uint32
	BoardID           uint32
	GpuInstance       uint32
	NumaID            int32
}

// +marshal
type NV0000_CTRL_GPU_ATTACH_IDS_PARAMS struct {
	_        structs.HostLayout
	GPUIDs   [NV0000_CTRL_GPU_MAX_PROBED_GPUS]uint32
	FailedID uint32
}

// +marshal
type NV0000_CTRL_GPU_GET_UUID_FROM_GPU_ID_PARAMS struct {
	_          structs.HostLayout
	GPUID      uint32
	Flags      uint32
	GPUUUID    [NV0000_GPU_MAX_GID_LENGTH]byte
	UUIDStrLen uint32
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000gsync.h:
const (
	NV0000_CTRL_CMD_GSYNC_GET_ATTACHED_IDS = 0x301
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000syncgpuboost.h:
const (
	NV0000_CTRL_CMD_SYNC_GPU_BOOST_GROUP_INFO = 0xa04
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000system.h:
const (
	NV0000_CTRL_CMD_SYSTEM_GET_BUILD_VERSION                = 0x101
	NV0000_CTRL_CMD_SYSTEM_GET_CPU_INFO                     = 0x102
	NV0000_CTRL_CMD_SYSTEM_GET_P2P_CAPS                     = 0x127
	NV0000_CTRL_CMD_SYSTEM_GET_P2P_CAPS_V2                  = 0x12b
	NV0000_CTRL_CMD_SYSTEM_GET_FABRIC_STATUS                = 0x136
	NV0000_CTRL_CMD_SYSTEM_GET_P2P_CAPS_MATRIX              = 0x13a
	NV0000_CTRL_CMD_SYSTEM_GET_FEATURES                     = 0x1f0
	NV0000_CTRL_SYSTEM_GET_BUILD_VERSION_V2_MAX_STRING_SIZE = 256
	NV0000_CTRL_SYSTEM_MAX_ATTACHED_GPUS                    = 32
	NV0000_CTRL_P2P_CAPS_INDEX_TABLE_SIZE                   = 9
)

// NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS is the param type for NV0000_CTRL_CMD_SYSTEM_GET_P2P_CAPS,
// from src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000system.h.
//
// +marshal
type NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS struct {
	_                  structs.HostLayout
	GpuIDs             [NV0000_CTRL_SYSTEM_MAX_ATTACHED_GPUS]uint32
	GpuCount           uint32
	P2PCaps            uint32
	P2POptimalReadCEs  uint32
	P2POptimalWriteCEs uint32
	P2PCapsStatus      [NV0000_CTRL_P2P_CAPS_INDEX_TABLE_SIZE]uint8
	_                  [7]byte
	BusPeerIDs         P64
}

// NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS_V550 is the updated version of
// NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS since 550.40.07.
//
// +marshal
type NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS_V550 struct {
	_ structs.HostLayout
	NV0000_CTRL_SYSTEM_GET_P2P_CAPS_PARAMS
	BusEgmPeerIDs P64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000unix.h:
const (
	NV0000_CTRL_CMD_OS_UNIX_EXPORT_OBJECT_TO_FD          = 0x3d05
	NV0000_CTRL_CMD_OS_UNIX_IMPORT_OBJECT_FROM_FD        = 0x3d06
	NV0000_CTRL_CMD_OS_UNIX_GET_EXPORT_OBJECT_INFO       = 0x3d08
	NV0000_CTRL_CMD_OS_UNIX_EXPORT_OBJECTS_TO_FD         = 0x3d0b
	NV0000_CTRL_CMD_OS_UNIX_IMPORT_OBJECTS_FROM_FD       = 0x3d0c
	NV0000_CTRL_OS_UNIX_CMD_MEMACCT_GET_LIMITS           = 0x3d0e
	NV0000_CTRL_OS_UNIX_CMD_MEMACCT_GET_IMPL             = 0x3d0f
	NV0000_OS_UNIX_EXPORT_OBJECT_FD_BUFFER_SIZE          = 64
	NV0000_CTRL_OS_UNIX_EXPORT_OBJECTS_TO_FD_MAX_OBJECTS = 512
	NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_TO_FD_MAX_OBJECTS = 128
	NV0000_CTRL_CMD_OS_UNIX_MEMACCT_CURRENT_PROCESS      = -1
)

// +marshal
type NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS struct {
	_              structs.HostLayout
	FD             int32
	DeviceInstance uint32
	MaxObjects     uint16
	Metadata       [NV0000_OS_UNIX_EXPORT_OBJECT_FD_BUFFER_SIZE]uint8
	Pad            [2]byte
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS) SetFrontendFD(fd int32) {
	p.FD = fd
}

// +marshal
type NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS_V545 struct {
	_              structs.HostLayout
	FD             int32
	DeviceInstance uint32
	GpuInstanceID  uint32
	MaxObjects     uint16
	Metadata       [NV0000_OS_UNIX_EXPORT_OBJECT_FD_BUFFER_SIZE]uint8
	Pad            [2]byte
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS_V545) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_GET_EXPORT_OBJECT_INFO_PARAMS_V545) SetFrontendFD(fd int32) {
	p.FD = fd
}

// +marshal
type NV0000_CTRL_OS_UNIX_EXPORT_OBJECT struct {
	_    structs.HostLayout
	Type uint32   // enum NV0000_CTRL_OS_UNIX_EXPORT_OBJECT_TYPE
	Data [12]byte // union
}

// +marshal
type NV0000_CTRL_OS_UNIX_EXPORT_OBJECT_TO_FD_PARAMS struct {
	_      structs.HostLayout
	Object NV0000_CTRL_OS_UNIX_EXPORT_OBJECT
	FD     int32
	Flags  uint32
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_EXPORT_OBJECT_TO_FD_PARAMS) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_EXPORT_OBJECT_TO_FD_PARAMS) SetFrontendFD(fd int32) {
	p.FD = fd
}

// +marshal
type NV0000_CTRL_OS_UNIX_IMPORT_OBJECT_FROM_FD_PARAMS struct {
	_      structs.HostLayout
	FD     int32
	Object NV0000_CTRL_OS_UNIX_EXPORT_OBJECT
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_IMPORT_OBJECT_FROM_FD_PARAMS) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_IMPORT_OBJECT_FROM_FD_PARAMS) SetFrontendFD(fd int32) {
	p.FD = fd
}

// +marshal
type NV0000_CTRL_OS_UNIX_EXPORT_OBJECTS_TO_FD_PARAMS struct {
	_          structs.HostLayout
	FD         int32
	HDevice    Handle
	MaxObjects uint16
	Metadata   [NV0000_OS_UNIX_EXPORT_OBJECT_FD_BUFFER_SIZE]uint8
	Pad        [2]byte
	Objects    [NV0000_CTRL_OS_UNIX_EXPORT_OBJECTS_TO_FD_MAX_OBJECTS]Handle
	NumObjects uint16
	Index      uint16
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_EXPORT_OBJECTS_TO_FD_PARAMS) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_EXPORT_OBJECTS_TO_FD_PARAMS) SetFrontendFD(fd int32) {
	p.FD = fd
}

// +marshal
type NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_FROM_FD_PARAMS struct {
	_           structs.HostLayout
	FD          int32
	HParent     Handle
	Objects     [NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_TO_FD_MAX_OBJECTS]Handle
	ObjectTypes [NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_TO_FD_MAX_OBJECTS]uint8
	NumObjects  uint16
	Index       uint16
}

// GetFrontendFD implements HasFrontendFD.GetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_FROM_FD_PARAMS) GetFrontendFD() int32 {
	return p.FD
}

// SetFrontendFD implements HasFrontendFD.SetFrontendFD.
func (p *NV0000_CTRL_OS_UNIX_IMPORT_OBJECTS_FROM_FD_PARAMS) SetFrontendFD(fd int32) {
	p.FD = fd
}

// NV0000_CTRL_OS_UNIX_MEMACCT_LIMITS is from
// src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000unix.h.
//
// +marshal
type NV0000_CTRL_OS_UNIX_MEMACCT_LIMITS struct {
	_       structs.HostLayout
	GpuID   uint32
	Pad     [4]byte
	Soft    uint64
	Hard    uint64
	Current uint64
}

// NV0000_CTRL_OS_UNIX_MEMACCT_GET_LIMITS_PARAMS is the param type for
// NV0000_CTRL_OS_UNIX_CMD_MEMACCT_GET_LIMITS, from
// src/common/sdk/nvidia/inc/ctrl/ctrl0000/ctrl0000unix.h.
//
// +marshal
type NV0000_CTRL_OS_UNIX_MEMACCT_GET_LIMITS_PARAMS struct {
	_        structs.HostLayout
	CgroupFD int32
	Count    uint32
	Limits   [NV0000_CTRL_GPU_MAX_ATTACHED_GPUS]NV0000_CTRL_OS_UNIX_MEMACCT_LIMITS
}

// +marshal
type NV0000_CTRL_SYSTEM_GET_BUILD_VERSION_PARAMS struct {
	_                        structs.HostLayout
	SizeOfStrings            uint32
	Pad                      [4]byte
	PDriverVersionBuffer     P64
	PVersionBuffer           P64
	PTitleBuffer             P64
	ChangelistNumber         uint32
	OfficialChangelistNumber uint32
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080dma.h.
const (
	NV0080_CTRL_CMD_DMA_ADV_SCHED_GET_VA_CAPS = 0x801806
	NV0080_CTRL_CMD_DMA_GET_CAPS              = 0x80180d
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0041.h
const (
	NV0041_CTRL_CMD_GET_SURFACE_INFO  = 0x410110
	NV0041_CTRL_CMD_GET_MEM_PAGE_SIZE = 0x410118
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080fb.h:
const (
	NV0080_CTRL_CMD_FB_GET_CAPS    = 0x801301
	NV0080_CTRL_CMD_FB_GET_CAPS_V2 = 0x801307
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080fifo.h:
const (
	NV0080_CTRL_CMD_FIFO_GET_CAPS                      = 0x801701
	NV0080_CTRL_CMD_FIFO_GET_ENGINE_CONTEXT_PROPERTIES = 0x801707
	NV0080_CTRL_CMD_FIFO_GET_CHANNELLIST               = 0x80170d
	NV0080_CTRL_CMD_FIFO_GET_CAPS_V2                   = 0x801713
)

// +marshal
type NV0080_CTRL_FIFO_GET_CHANNELLIST_PARAMS struct {
	_                  structs.HostLayout
	NumChannels        uint32
	Pad                [4]byte
	PChannelHandleList P64
	PChannelList       P64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080gpu.h:
const (
	NV0080_CTRL_CMD_GPU_GET_CLASSLIST              = 0x800201
	NV0080_CTRL_CMD_GPU_GET_NUM_SUBDEVICES         = 0x800280
	NV0080_CTRL_CMD_GPU_QUERY_SW_STATE_PERSISTENCE = 0x800288
	NV0080_CTRL_CMD_GPU_GET_VIRTUALIZATION_MODE    = 0x800289
	NV0080_CTRL_CMD_GPU_GET_CLASSLIST_V2           = 0x800292
)

// RmapiParamNvU32List is used to represent the following types:
// - NV0080_CTRL_GPU_GET_CLASSLIST_PARAMS
// - NV2080_CTRL_GPU_GET_ENGINES_PARAMS
//
// +marshal
type RmapiParamNvU32List struct {
	_        structs.HostLayout
	NumElems uint32
	Pad      [4]byte
	List     P64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080gr.h:
const (
	NV0080_CTRL_CMD_GR_GET_CAPS               = 0x801102
	NV0080_CTRL_CMD_GR_GET_INFO               = 0x801104
	NV0080_CTRL_CMD_GR_SET_TPC_PARTITION_MODE = 0x801108
	NV0080_CTRL_CMD_GR_GET_CAPS_V2            = 0x801109
)

// NV0080_CTRL_GET_CAPS_PARAMS is used to represent the following:
// - NV0080_CTRL_FB_GET_CAPS_PARAMS
// - NV0080_CTRL_GR_GET_CAPS_PARAMS
// - NV0080_CTRL_FIFO_GET_CAPS_PARAMS
// - NV0080_CTRL_MSENC_GET_CAPS_PARAMS
// - NV0080_CTRL_NVENC_GET_CAPS_PARAMS
//
// +marshal
type NV0080_CTRL_GET_CAPS_PARAMS struct {
	_           structs.HostLayout
	CapsTblSize uint32
	Pad         [4]byte
	CapsTbl     P64
}

// +marshal
type NV0080_CTRL_GR_ROUTE_INFO struct {
	_     structs.HostLayout
	Flags uint32
	Pad   [4]byte
	Route uint64
}

const (
	// From src/common/sdk/nvidia/inc/ctrl/ctrl208f/ctrl208fgpu.h
	NV208F_CTRL_CMD_GPU_VERIFY_INFOROM = 0x208f1105
)

// NV208F_CTRL_GPU_VERIFY_INFOROM_PARAMS is used to represent to determine if an InfoROM with a
// valid image is present.
//
// +marshal
type NV208F_CTRL_GPU_VERIFY_INFOROM_PARAMS struct {
	_        structs.HostLayout
	Result   uint32
	Checksum uint32
}

// NvxxxCtrlXxxGetInfoParams is used to represent the following:
// - NV0080_CTRL_GR_GET_INFO_PARAMS
// - NV2080_CTRL_FB_GET_INFO_PARAMS
// - NV0041_CTRL_GET_SURFACE_INFO_PARAMS
// - NV2080_CTRL_BIOS_GET_INFO_PARAMS
// - NV2080_CTRL_BUS_GET_INFO_PARAMS
//
// +marshal
type NvxxxCtrlXxxGetInfoParams struct {
	_            structs.HostLayout
	InfoListSize uint32
	Pad          [4]byte
	InfoList     P64
}

// ListSize implements HasCtrlInfoList.ListSize.
func (p *NvxxxCtrlXxxGetInfoParams) ListSize() uint32 {
	return p.InfoListSize
}

// SetCtrlInfoList implements HasCtrlInfoList.SetCtrlInfoList.
func (p *NvxxxCtrlXxxGetInfoParams) SetCtrlInfoList(ptr P64) {
	p.InfoList = ptr
}

// CtrlInfoList implements HasCtrlInfoList.CtrlInfoList.
func (p *NvxxxCtrlXxxGetInfoParams) CtrlInfoList() P64 {
	return p.InfoList
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080host.h:
const (
	NV0080_CTRL_CMD_HOST_GET_CAPS_V2 = 0x801402
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080perf.h:
const (
	NV0080_CTRL_CMD_PERF_CUDA_LIMIT_SET_CONTROL = 0x801909
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080msenc.h:
const (
	NV0080_CTRL_CMD_MSENC_GET_CAPS = 0x801b01
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080bsp.h
const (
	NV0080_CTRL_CMD_BSP_GET_CAPS_V2 = 0x801c02
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0080/ctrl0080nvjpg.h
const (
	NV0080_CTRL_CMD_NVJPG_GET_CAPS_V2 = 0x801f02
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl0090.h:
const (
	NV0090_CTRL_CMD_SET_LG_SECTOR_PROMOTION = 0x90010b
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00da.h:
const (
	NV_SEMAPHORE_SURFACE_CTRL_CMD_BIND_CHANNEL   = 0xda0002
	NV_SEMAPHORE_SURFACE_CTRL_CMD_UNBIND_CHANNEL = 0xda0006
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00de.h
const (
	NV00DE_CTRL_CMD_REQUEST_DATA_POLL = 0xde0001
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00e0.h:
const (
	NV00E0_CTRL_CMD_IMPORT_MEM = 0xe00102
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00f1.h:
const (
	NV00F1_CTRL_CMD_GET_FABRIC_EVENTS   = 0xf10001
	NV00F1_CTRL_CMD_FINISH_MEM_UNIMPORT = 0xf10002
	NV00F1_CTRL_CMD_DISABLE_IMPORTERS   = 0xf10003
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00f8.h:
const (
	NV00F8_CTRL_CMD_DESCRIBE   = 0xf80102
	NV00F8_CTRL_CMD_ATTACH_MEM = 0xf80103
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00fb.h:
const (
	NV00FB_CTRL_CMD_VALIDATE = 0xfb0101
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00fd.h:
const (
	NV00FD_CTRL_CMD_GET_INFO          = 0xfd0101
	NV00FD_CTRL_CMD_ATTACH_MEM        = 0xfd0102
	NV00FD_CTRL_CMD_ATTACH_GPU        = 0xfd0104
	NV00FD_CTRL_CMD_DETACH_MEM        = 0xfd0105
	NV00FD_CTRL_CMD_ATTACH_REMOTE_GPU = 0xfd0106
	NV00FD_CTRL_CMD_SET_FAILURE       = 0xfd0107
)

// +marshal
type NV00FD_CTRL_ATTACH_GPU_PARAMS struct {
	_             structs.HostLayout
	HSubDevice    Handle
	Flags         uint32
	DevDescriptor uint64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080bios.h:
const (
	NV2080_CTRL_CMD_BIOS_GET_INFO = 0x20800802
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080bus.h:
const (
	NV2080_CTRL_CMD_BUS_GET_PCI_INFO                   = 0x20801801
	NV2080_CTRL_CMD_BUS_GET_PCI_BAR_INFO               = 0x20801803
	NV2080_CTRL_CMD_BUS_GET_INFO                       = 0x20801802
	NV2080_CTRL_CMD_BUS_GET_INFO_V2                    = 0x20801823
	NV2080_CTRL_CMD_BUS_GET_PCIE_SUPPORTED_GPU_ATOMICS = 0x2080182a
	NV2080_CTRL_CMD_BUS_GET_C2C_INFO                   = 0x2080182b
	NV2080_CTRL_CMD_BUS_GET_PEX_COUNTERS               = 0x20801813
	NV2080_CTRL_CMD_BUS_GET_PEX_UTIL_COUNTERS          = 0x20801819
	NV2080_CTRL_CMD_BUS_GET_PCIE_REQ_ATOMICS_CAPS      = 0x20801829
	NV2080_CTRL_CMD_BUS_GET_PCIE_CPL_ATOMICS_CAPS      = 0x20801830
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080ce.h:
const (
	NV2080_CTRL_CMD_CE_GET_CE_PCE_MASK   = 0x20802a02
	NV2080_CTRL_CMD_CE_GET_CAPS_V2       = 0x20802a03
	NV2080_CTRL_CMD_CE_GET_ALL_CAPS      = 0x20802a0a
	NV2080_CTRL_CMD_CE_GET_LCE_SHIM_INFO = 0x20802a0c
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080event.h:
const (
	NV2080_CTRL_CMD_EVENT_SET_NOTIFICATION  = 0x20800301
	NV2080_CTRL_CMD_EVENT_SET_TRIGGER_FIFO  = 0x20800308
	NV2080_CTRL_CMD_EVENT_VIDEO_BIND_EVTBUF = 0x20800309
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl90cd.h.
const (
	NV_EVENT_BUFFER_CTRL_CMD_ENABLE_EVENTS = 0x90cd0101
	NV_EVENT_BUFFER_CTRL_CMD_UPDATE_GET    = 0x90cd0102
	NV_EVENT_BUFFER_CTRL_CMD_FLUSH         = 0x90cd0104
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080ecc.h:
const (
	NV2080_CTRL_CMD_ECC_GET_REPAIR_STATUS = 0x20803404
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080fb.h:
const (
	NV2080_CTRL_CMD_FB_GET_INFO                                    = 0x20801301
	NV2080_CTRL_CMD_FB_GET_INFO_V2                                 = 0x20801303
	NV2080_CTRL_CMD_FB_GET_GPU_CACHE_INFO                          = 0x20801315
	NV2080_CTRL_CMD_FB_GET_FB_REGION_INFO                          = 0x20801320
	NV2080_CTRL_CMD_FB_GET_SEMAPHORE_SURFACE_LAYOUT                = 0x20801352
	NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_INFOROM_SUPPORT       = 0x20801358
	NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_STATUS                = 0x20801359
	NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_INFOROM_SUPPORT_V575  = NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_INFOROM_SUPPORT - 1
	NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_STATUS_V575           = NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_STATUS - 1
	NV2080_CTRL_CMD_FB_GET_OFFLINED_PAGES                          = 0x20801322
	NV2080_CTRL_CMD_FB_FLUSH_GPU_CACHE                             = 0x2080130e
	NV2080_CTRL_CMD_FB_QUERY_DRAM_ENCRYPTION_PENDING_CONFIGURATION = 0x20801355
	NV2080_CTRL_CMD_FB_GET_FS_INFO                                 = 0x20801346
	NV2080_CTRL_CMD_FB_GET_UGPU_MEMORY_INFO                        = 0x20801362
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080fifo.h:
const (
	NV2080_CTRL_CMD_FIFO_DISABLE_CHANNELS = 0x2080110b

	NV2080_CTRL_FIFO_DISABLE_CHANNELS_MAX_ENTRIES = 64
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080fla.h:
const (
	NV2080_CTRL_CMD_FLA_GET_FABRIC_MEM_STATS = 0x20803504
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080flcn.h:
const (
	NV2080_CTRL_CMD_FLCN_GET_CTX_BUFFER_SIZE = 0x20803125
)

// +marshal
type NV2080_CTRL_FIFO_DISABLE_CHANNELS_PARAMS struct {
	_                      structs.HostLayout
	BDisable               uint8
	Pad1                   [3]byte
	NumChannels            uint32
	BOnlyDisableScheduling uint8
	BRewindGpPut           uint8
	Pad2                   [6]byte
	PRunlistPreemptEvent   P64
	HClientList            [NV2080_CTRL_FIFO_DISABLE_CHANNELS_MAX_ENTRIES]Handle
	HChannelList           [NV2080_CTRL_FIFO_DISABLE_CHANNELS_MAX_ENTRIES]Handle
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080gpu.h:
const (
	NV2080_CTRL_CMD_GPU_GET_INFO_V2                      = 0x20800102
	NV2080_CTRL_CMD_GPU_GET_NAME_STRING                  = 0x20800110
	NV2080_CTRL_CMD_GPU_GET_SHORT_NAME_STRING            = 0x20800111
	NV2080_CTRL_CMD_GPU_GET_SIMULATION_INFO              = 0x20800119
	NV2080_CTRL_CMD_GPU_GET_ENGINES                      = 0x20800123
	NV2080_CTRL_CMD_GPU_QUERY_ECC_STATUS                 = 0x2080012f
	NV2080_CTRL_CMD_GPU_QUERY_COMPUTE_MODE_RULES         = 0x20800131
	NV2080_CTRL_CMD_GPU_QUERY_ECC_CONFIGURATION          = 0x20800133
	NV2080_CTRL_CMD_GPU_GET_OEM_BOARD_INFO               = 0x2080013f
	NV2080_CTRL_CMD_GPU_GET_ID                           = 0x20800142
	NV2080_CTRL_CMD_GPU_ACQUIRE_COMPUTE_MODE_RESERVATION = 0x20800145 // undocumented; paramSize == 0
	NV2080_CTRL_CMD_GPU_RELEASE_COMPUTE_MODE_RESERVATION = 0x20800146 // undocumented; paramSize == 0
	NV2080_CTRL_CMD_GPU_GET_ENGINE_PARTNERLIST           = 0x20800147
	NV2080_CTRL_CMD_GPU_GET_GID_INFO                     = 0x2080014a
	NV2080_CTRL_CMD_GPU_GET_INFOROM_OBJECT_VERSION       = 0x2080014b
	NV2080_CTRL_CMD_GPU_GET_INFOROM_IMAGE_VERSION        = 0x20800156
	NV2080_CTRL_CMD_GPU_QUERY_INFOROM_ECC_SUPPORT        = 0x20800157
	NV2080_CTRL_CMD_GPU_GET_ENCODER_CAPACITY             = 0x2080016c
	NV2080_CTRL_CMD_GPU_GET_ENGINES_V2                   = 0x20800170
	NV2080_CTRL_CMD_GPU_GET_PARTITION_CAPACITY           = 0x20800181
	NV2080_CTRL_CMD_GPU_DESCRIBE_PARTITIONS              = 0x20800185
	NV2080_CTRL_CMD_GPU_GET_ACTIVE_PARTITION_IDS         = 0x2080018b
	NV2080_CTRL_CMD_GPU_GET_PIDS                         = 0x2080018d
	NV2080_CTRL_CMD_GPU_GET_PID_INFO                     = 0x2080018e
	NV2080_CTRL_CMD_GPU_GET_COMPUTE_POLICY_CONFIG        = 0x20800195
	NV2080_CTRL_CMD_GET_GPU_FABRIC_PROBE_INFO            = 0x208001a3
	NV2080_CTRL_CMD_GPU_GET_RESET_STATUS                 = 0x208001ab
	NV2080_CTRL_CMD_GPU_GET_DRAIN_AND_RESET_STATUS       = 0x208001ae
	NV2080_CTRL_CMD_GPU_GET_NVENC_SW_SESSION_STATS       = 0x2080016d
	NV2080_CTRL_CMD_GPU_GET_NVFBC_SW_SESSION_STATS       = 0x2080017b
	NV2080_CTRL_CMD_GPU_GET_SKYLINE_INFO                 = 0x2080019f
	NV2080_CTRL_CMD_GPU_GET_CHIP_DETAILS                 = 0x208001a4
	NV2080_CTRL_CMD_GPU_GET_RECOVERY_ACTION              = 0x208001b2
	NV2080_CTRL_CMD_GPU_EXEC_REG_OPS                     = 0x20800122
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080gr.h:
const (
	NV2080_CTRL_CMD_GR_GET_INFO                      = 0x20801201
	NV2080_CTRL_CMD_GR_GET_ZCULL_INFO                = 0x20801206
	NV2080_CTRL_CMD_GR_CTXSW_ZCULL_BIND              = 0x20801208
	NV2080_CTRL_CMD_GR_GET_SM_TO_GPC_TPC_MAPPINGS    = 0x2080120f
	NV2080_CTRL_CMD_GR_SET_CTXSW_PREEMPTION_MODE     = 0x20801210
	NV2080_CTRL_CMD_GR_GET_CTX_BUFFER_SIZE           = 0x20801218
	NV2080_CTRL_CMD_GR_GET_GLOBAL_SM_ORDER           = 0x2080121b
	NV2080_CTRL_CMD_GR_GET_CAPS_V2                   = 0x20801227
	NV2080_CTRL_CMD_GR_GET_GPC_MASK                  = 0x2080122a
	NV2080_CTRL_CMD_GR_GET_TPC_MASK                  = 0x2080122b
	NV2080_CTRL_CMD_GR_GET_SM_ISSUE_RATE_MODIFIER    = 0x20801230
	NV2080_CTRL_CMD_GR_FECS_BIND_EVTBUF_FOR_UID      = 0x20801231
	NV2080_CTRL_CMD_GR_GET_SM_ISSUE_RATE_MODIFIER_V2 = 0x2080123c
	NV2080_CTRL_CMD_GR_GET_SM_ISSUE_THROTTLE_CTRL    = 0x2080123d
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080grmgr.h:
const (
	NV2080_CTRL_CMD_GRMGR_GET_GR_FS_INFO = 0x20803801
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080gsp.h:
const (
	NV2080_CTRL_CMD_GSP_GET_FEATURES = 0x20803601
)

// +marshal
type NV2080_CTRL_GR_GET_INFO_PARAMS struct {
	_ structs.HostLayout
	NvxxxCtrlXxxGetInfoParams
	GRRouteInfo NV0080_CTRL_GR_ROUTE_INFO
}

// ListSize implements HasCtrlInfoList.ListSize.
func (p *NV2080_CTRL_GR_GET_INFO_PARAMS) ListSize() uint32 {
	return p.InfoListSize
}

// SetCtrlInfoList implements HasCtrlInfoList.SetCtrlInfoList.
func (p *NV2080_CTRL_GR_GET_INFO_PARAMS) SetCtrlInfoList(ptr P64) {
	p.InfoList = ptr
}

// CtrlInfoList implements HasCtrlInfoList.CtrlInfoList.
func (p *NV2080_CTRL_GR_GET_INFO_PARAMS) CtrlInfoList() P64 {
	return p.InfoList
}

// NV2080_CTRL_GPU_REG_OP is the type of an individual register operation,
// from src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080gpu.h.
//
// +marshal
type NV2080_CTRL_GPU_REG_OP struct {
	_               structs.HostLayout
	RegOp           uint8
	RegType         uint8
	RegStatus       uint8
	RegQuad         uint8
	RegGroupMask    uint32
	RegSubGroupMask uint32
	RegOffset       uint32
	RegValueHi      uint32
	RegValueLo      uint32
	RegAndNMaskHi   uint32
	RegAndNMaskLo   uint32
}

// CtrlGpuRegOpSize is sizeof(NV2080_CTRL_GPU_REG_OP).
var CtrlGpuRegOpSize = uint32((*NV2080_CTRL_GPU_REG_OP)(nil).SizeBytes())

// NV2080_CTRL_GPU_EXEC_REG_OPS_PARAMS is the params type for
// NV2080_CTRL_CMD_GPU_EXEC_REG_OPS, from
// src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080gpu.h.
//
// +marshal
type NV2080_CTRL_GPU_EXEC_REG_OPS_PARAMS struct {
	_                 structs.HostLayout
	HClientTarget     Handle
	HChannelTarget    Handle
	BNonTransactional uint32
	Reserved00        [2]uint32
	RegOpCount        uint32
	RegOps            P64
	GRRouteInfo       NV0080_CTRL_GR_ROUTE_INFO
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080mc.h:
const (
	NV2080_CTRL_CMD_MC_GET_ARCH_INFO      = 0x20801701
	NV2080_CTRL_CMD_MC_SERVICE_INTERRUPTS = 0x20801702
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080nvlink.h:
const (
	NV2080_CTRL_CMD_NVLINK_GET_NVLINK_CAPS           = 0x20803001
	NV2080_CTRL_CMD_NVLINK_GET_NVLINK_STATUS         = 0x20803002
	NV2080_CTRL_CMD_NVLINK_GET_PLATFORM_INFO         = 0x20803083
	NV2080_CTRL_CMD_NVLINK_LOCK_REMAP_TABLE_AND_MSE  = 0x2080309d
	NV2080_CTRL_CMD_NVLINK_SETUP_NVLE_ENCRYPTION_KEY = 0x208030a0
	NV2080_CTRL_CMD_NVLINK_GET_REMAP_TABLE_INFO_V2   = 0x208030a1
	NV2080_CTRL_CMD_NVLINK_GET_UPDATE_NVLE_LIDS_V2   = 0x208030a2
	NV2080_CTRL_CMD_NVLINK_GET_UPDATE_NVLE_LIDS_V3   = 0x208030a3
	NV2080_CTRL_CMD_NVLINK_SET_NVLE_READY            = 0x208030a5
)

// Constants from src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080nvlink.h.
const (
	NV2080_CTRL_NVLINK_MAX_REMAP_TABLE_ENTRIES_V2 = 4096
	NV2080_CTRL_NVLINK_REMAP_TABLE_ENTRIES_CHUNK  = 128
)

// NV2080_CTRL_NVLINK_GET_REMAP_TABLE_INFO_V2_PARAMS is the params type for
// NV2080_CTRL_CMD_NVLINK_GET_REMAP_TABLE_INFO_V2, from
// src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080nvlink.h.
//
// +marshal
type NV2080_CTRL_NVLINK_GET_REMAP_TABLE_INFO_V2_PARAMS struct {
	_               structs.HostLayout
	Alid            uint32
	FlaRemapTabAddr [NV2080_CTRL_NVLINK_REMAP_TABLE_ENTRIES_CHUNK]uint32
	GpaRemapTabAddr [NV2080_CTRL_NVLINK_REMAP_TABLE_ENTRIES_CHUNK]uint32
	RemapTabSize    uint32
	RemapEntryStart uint32
	RemapEntryEnd   uint32
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080perf.h:
const (
	NV2080_CTRL_CMD_PERF_RATED_TDP_SET_CONTROL              = 0x2080206f
	NV2080_CTRL_CMD_PERF_BOOST                              = 0x2080200a
	NV2080_CTRL_CMD_PERF_GET_CURRENT_PSTATE                 = 0x20802068
	NV2080_CTRL_CMD_PERF_GET_GPUMON_PERFMON_UTIL_SAMPLES_V2 = 0x20802096
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080rc.h:
const (
	NV2080_CTRL_CMD_RC_GET_WATCHDOG_INFO         = 0x20802209
	NV2080_CTRL_CMD_RC_RELEASE_WATCHDOG_REQUESTS = 0x2080220c
	NV2080_CTRL_CMD_RC_SOFT_DISABLE_WATCHDOG     = 0x20802210
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080tmr.h:
const (
	NV2080_CTRL_CMD_TIMER_GET_TIME                          = 0x20800403
	NV2080_CTRL_CMD_TIMER_GET_GPU_CPU_TIME_CORRELATION_INFO = 0x20800406
	NV2080_CTRL_CMD_TIMER_SET_GR_TICK_FREQ                  = 0x20800407
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080thermal.h:
const (
	NV2080_CTRL_CMD_THERMAL_SYSTEM_EXECUTE_V2 = 0x20800513
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl2080/ctrl2080unix.h:
const (
	NV2080_CTRL_CMD_OS_UNIX_VIDMEM_PERSISTENCE_STATUS = 0x20803d07
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl503c.h:
const (
	NV503C_CTRL_CMD_REGISTER_VA_SPACE = 0x503c0102
	NV503C_CTRL_CMD_REGISTER_VIDMEM   = 0x503c0104
	NV503C_CTRL_CMD_UNREGISTER_VIDMEM = 0x503c0105
)

// +marshal
type NV503C_CTRL_REGISTER_VA_SPACE_PARAMS struct {
	_            structs.HostLayout
	HVASpace     Handle
	Pad          [4]byte
	VASpaceToken uint64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrl83de/ctrl83dedebug.h:
const (
	NV83DE_CTRL_CMD_DEBUG_SET_MODE_MMU_DEBUG        = 0x83de0307
	NV83DE_CTRL_CMD_DEBUG_SET_EXCEPTION_MASK        = 0x83de0309
	NV83DE_CTRL_CMD_DEBUG_READ_ALL_SM_ERROR_STATES  = 0x83de030c
	NV83DE_CTRL_CMD_DEBUG_CLEAR_ALL_SM_ERROR_STATES = 0x83de0310
	NV83DE_CTRL_CMD_DEBUG_READ_MEMORY               = 0x83de0315
	NV83DE_CTRL_CMD_DEBUG_SUSPEND_CONTEXT           = 0x83de0317
	NV83DE_CTRL_CMD_DEBUG_RESUME_CONTEXT            = 0x83de0318
	NV83DE_CTRL_CMD_DEBUG_SET_MODE_ERRBAR_DEBUG     = 0x83de031f
)

// NV83DE_CTRL_DEBUG_READ_MEMORY_PARAMS is the params type for
// NV83DE_CTRL_CMD_DEBUG_READ_MEMORY, from
// src/common/sdk/nvidia/inc/ctrl/ctrl83de/ctrl83dedebug.h.
//
// +marshal
type NV83DE_CTRL_DEBUG_READ_MEMORY_PARAMS struct {
	_       structs.HostLayout
	HMemory uint32
	Length  uint32
	Offset  uint64
	Buffer  P64
}

// From src/common/sdk/nvidia/inc/ctrl/ctrlc36f.h:
const (
	NVC36F_CTRL_GET_CLASS_ENGINEID                           = 0xc36f0101
	NVC36F_CTRL_CMD_GPFIFO_GET_WORK_SUBMIT_TOKEN             = 0xc36f0108
	NVC36F_CTRL_CMD_GPFIFO_SET_WORK_SUBMIT_TOKEN_NOTIF_INDEX = 0xc36f010a
)

// From src/common/sdk/nvidia/inc/ctrl/ctrlc56f.h:
const (
	NVC56F_CTRL_CMD_GET_KMB = 0xc56f010b
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl906f.h:
const (
	NV906F_CTRL_GET_CLASS_ENGINEID     = 0x906f0101
	NV906F_CTRL_CMD_RESET_CHANNEL      = 0x906f0102
	NV906F_CTRL_CMD_GET_MMU_FAULT_INFO = 0x906f0106
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl9096.h:
const (
	NV9096_CTRL_CMD_GET_ZBC_CLEAR_TABLE_SIZE  = 0x90960106
	NV9096_CTRL_CMD_GET_ZBC_CLEAR_TABLE_ENTRY = 0x90960107
	NV9096_CTRL_CMD_SET_ZBC_COLOR_CLEAR       = 0x90960101
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl90e6.h:
const (
	NV90E6_CTRL_CMD_MASTER_GET_VIRTUAL_FUNCTION_ERROR_CONT_INTR_MASK = 0x90e60102
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl90e7/ctrl90e7bbx.h:
const (
	NV90E7_CTRL_CMD_BBX_GET_LAST_FLUSH_TIME = 0x90e70113
)

// From src/common/sdk/nvidia/inc/ctrl/ctrla06c.h:
const (
	NVA06C_CTRL_CMD_GPFIFO_SCHEDULE = 0xa06c0101
	NVA06C_CTRL_CMD_SET_TIMESLICE   = 0xa06c0103
	NVA06C_CTRL_CMD_GET_TIMESLICE   = 0xa06c0104
	NVA06C_CTRL_CMD_PREEMPT         = 0xa06c0105
)

// From src/common/sdk/nvidia/inc/ctrl/ctrla06f/ctrla06fgpfifo.h:
const (
	NVA06F_CTRL_CMD_GPFIFO_SCHEDULE = 0xa06f0103
	NVA06F_CTRL_CMD_BIND            = 0xa06f0104
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl90cc.h:
const (
	NV90CC_CTRL_CMD_POWER_REQUEST_FEATURES = 0x90cc0301
	NV90CC_CTRL_CMD_POWER_RELEASE_FEATURES = 0x90cc0302
)

// From src/common/sdk/nvidia/inc/ctrl/ctrlb0cc.h:
const (
	NVB0CC_CTRL_CMD_RESERVE_HWPM_LEGACY        = 0xb0cc0101
	NVB0CC_CTRL_CMD_RELEASE_HWPM_LEGACY        = 0xb0cc0102
	NVB0CC_CTRL_CMD_RESERVE_PM_AREA_SMPC       = 0xb0cc0103
	NVB0CC_CTRL_CMD_RELEASE_PM_AREA_SMPC       = 0xb0cc0104
	NVB0CC_CTRL_CMD_ALLOC_PMA_STREAM           = 0xb0cc0105
	NVB0CC_CTRL_CMD_FREE_PMA_STREAM            = 0xb0cc0106
	NVB0CC_CTRL_CMD_BIND_PM_RESOURCES          = 0xb0cc0107
	NVB0CC_CTRL_CMD_UNBIND_PM_RESOURCES        = 0xb0cc0108
	NVB0CC_CTRL_CMD_PMA_STREAM_UPDATE_GET_PUT  = 0xb0cc0109
	NVB0CC_CTRL_CMD_EXEC_REG_OPS               = 0xb0cc010a
	NVB0CC_CTRL_CMD_RESERVE_PM_AREA_PC_SAMPLER = 0xb0cc010b
	NVB0CC_CTRL_CMD_RELEASE_PM_AREA_PC_SAMPLER = 0xb0cc010c
	NVB0CC_CTRL_CMD_GET_TOTAL_HS_CREDITS       = 0xb0cc010d
	NVB0CC_CTRL_CMD_SET_HS_CREDITS             = 0xb0cc010e
	NVB0CC_CTRL_CMD_RESERVE_HES                = 0xb0cc0113
	NVB0CC_CTRL_CMD_GET_CHIPLET_HS_CREDIT_POOL = 0xb0cc0115
	NVB0CC_CTRL_CMD_GET_HS_CREDITS_MAPPING     = 0xb0cc0116
	NVB0CC_CTRL_CMD_RESERVE_CCU_PROF           = 0xb0cc0119
	NVB0CC_CTRL_CMD_POWER_REQUEST_FEATURES     = 0xb0cc0301
	NVB0CC_CTRL_CMD_POWER_RELEASE_FEATURES     = 0xb0cc0302
)

// From src/common/sdk/nvidia/inc/ctrl/ctrlcbca.h:
const (
	NV_COUNTER_COLLECTION_UNIT_CTRL_CMD_SUBSCRIBE        = 0xcbca0101
	NV_COUNTER_COLLECTION_UNIT_CTRL_CMD_UNSUBSCRIBE      = 0xcbca0102
	NV_COUNTER_COLLECTION_UNIT_CTRL_CMD_SET_STREAM_STATE = 0xcbca0103
	NV_COUNTER_COLLECTION_UNIT_CTRL_CMD_GET_STREAM_STATE = 0xcbca0104
)

// From src/common/sdk/nvidia/inc/ctrl/ctrlcb33.h:
const (
	NV_CONF_COMPUTE_CTRL_CMD_SYSTEM_GET_CAPABILITIES     = 0xcb330101
	NV_CONF_COMPUTE_CTRL_CMD_SYSTEM_GET_GPUS_STATE       = 0xcb330104
	NV_CONF_COMPUTE_CTRL_CMD_GPU_GET_VIDMEM_SIZE         = 0xcb330106
	NV_CONF_COMPUTE_CTRL_CMD_GPU_GET_NUM_SECURE_CHANNELS = 0xcb33010b
	NV_CONF_COMPUTE_CTRL_CMD_GPU_GET_KEY_ROTATION_STATE  = 0xcb33010c
)

// From src/common/sdk/nvidia/inc/ctrl/ctrl00fe.h:
const (
	NV00FE_CTRL_CMD_SUBMIT_OPERATIONS = 0xfe0101
	NV00FE_CTRL_CMD_RESIZE_QUEUE      = 0xfe0102
)

// The following IOCTLs are not found in the OSS repo.
const (
	UNKNOWN_CONTROL_COMMAND_80028B = 0x80028b
)
